import React from 'react';
import {Route, Routes, useLocation } from 'react-router-dom';
import All from './components/All';
import MernStack from './components/courses/MernStack';
import MeanStack from './components/courses/MeanStack';
import { Devops } from './components/courses/Devops';
import { DataScience } from './components/courses/DataScience';
import Login from './components/Forms/Login';
import Register from './components/Forms/Register';
import { useEffect } from 'react';
import { Footer } from './components/Footer';
import ForgotPassword from './components/Forms/ForgotPassword';
import ResetPassword from './components/Forms/ResetPassword';
import Enroll from './components/Forms/Enroll';
import Terms from './components/Terms';
import Privacy from './components/Privacy';
import Contact from './components/Contact';
import Internship from './components/Internship';
import { PopupProvider } from './PopupProvider';
import Sidebar from './components/StudentDashBoard/Sidebar';
import CourseVideos from './components/StudentDashBoard/CourseVideos';

function App() {

  const {pathname} = useLocation()
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
   
      <PopupProvider>
        <div>
          <Routes>
            <Route path="/" element={<All />} />
            <Route path="/login" element={<Login />} />
            <Route path="/Enroll" element={<Enroll />} />
            <Route path="/mernstack" element={<MernStack />} />
            <Route path="/meanstack" element={<MeanStack />} />
            <Route path="/devops" element={<Devops />} />
            <Route path="/datascience" element={<DataScience />} />
            <Route path="/signup" element={<Register />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/resetPassword" element={<ResetPassword />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/internship" element={<Internship />} />
            <Route path="/StudentDashboard" element={<Sidebar />} />
            <Route path="/CourseVideos" element={<CourseVideos />} />
          </Routes>
        </div>
      </PopupProvider>
  
  );
}

export default App;
