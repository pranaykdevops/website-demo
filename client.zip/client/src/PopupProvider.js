import React, { createContext,  useState } from 'react';

const PopupContext = createContext();

function PopupProvider({ children }) {
  const [isPopup1Open, setPopup1Open] = useState(false);
  const [isPopup2Open, setPopup2Open] = useState(false);
  const [isPopup3Open, setPopup3Open] = useState(false);
  const [isPopup4Open, setPopup4Open] = useState(false);
  const [successtext, setSuccesstext]=React.useState({
    title:"",
    message:""
  })
const [id,setId] = useState("")


const handleBatchId = (id) => {
  setId(id)
}
  const openPopup1 = () => {
  
    setPopup1Open(true);
  };

  const closePopup1 = () => {

    setPopup1Open(false);
  };

  const openPopup2 = (logintext,loginmessage) => { 
    setSuccesstext({
      title:logintext,
      message:loginmessage,
    })
   
    setPopup2Open(true);
  };

  const closePopup2 = () => {
  
    setPopup2Open(false);
  };

   const closePopup3 = () => {
  
    setPopup3Open(false);
  };

  const openPopup3 = () => { 
   
  
    setPopup3Open(true);
  };
  const closePopup4 = () => {
    
  
    setPopup4Open(false);
  };

  const openPopup4 = (coursename,message) => { 
 
    setSuccesstext({
      title:coursename,
      message:message,
    })
   
    setPopup4Open(true);
  };

  const contextValue = {
    successtext,
    isPopup1Open,
    isPopup2Open,
    isPopup3Open,
    isPopup4Open,
    id,
    openPopup1,
    closePopup1,
    openPopup2,
    closePopup2,
    openPopup3,
    closePopup3,
    openPopup4,
    closePopup4,
    handleBatchId
  };

  return (
    <PopupContext.Provider value={contextValue}>
      {children}
    </PopupContext.Provider>
  );
}

export { PopupProvider, PopupContext };
