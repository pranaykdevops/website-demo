import React, { useEffect, useState } from 'react'
import '../css/aboutus.css'

const Aboutus = () => {
  const [trailStyle, setTrailStyle] = useState({
    left: 0,
    top: 0,
  });

  useEffect(() => {
    const handleMouseMove = (e) => {

      setTrailStyle({
        left: e.clientX + "px",
        top: e.clientY + "px",
      });
    };

    document.addEventListener("mousemove", handleMouseMove);

    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
    };
  }, []);
  return (
    <>
      <div className='main '>

        <div className="container-fluid row gx-0 mycontainer">
          <div className='abtus'>
            <p className='aboutusp '>About us</p>
            <h1 className='aboutush1'>Increase your expertise in planning Career, Job life.</h1>
            <p className='abouttext-wrap'>
              In an ever-evolving job market, staying ahead requires continuous learning and adaptability.
              Whether you're a student exploring future career paths, a professional aiming to advance in your current job,
              or someone considering a career change, we're here to support you.

              Our mission is to empower individuals like you to make informed decisions about your careers.
              We offer a wide range of resources, including articles, guides, and expert advice, to help you
              navigate the complexities of planning your career and achieving your professional goals.

            </p>
          </div>
          
          <div className="col first">
            <div className='first-div'>
              <div className="card " style={{ height: '15rem' }}>
                <div className="card-body about-card">
                  <div className="card-img-top about-img">
                    <img src="../images/rocket.png" className='abt-image' alt="..." height={60} width={60} />
                  </div>
                  <h5 className="card-title about-title">Consistency</h5>
                  <p className="card-text about-text">Consistency is the bedrock of progress and the cornerstone of success. It is the unwavering commitment to our goals
                    and values that propels us forward, even in the face of challenges.
                  </p>
                </div>
              </div>
              <div className="card" style={{ height: '15rem' }}>
                <div className="card-body about-card">
                  <div className="card-img-top about-img">
                    <img src="../images/videocall.png" className='abt-image' alt="..." height={60} width={60} />
                  </div>
                  <h5 className="card-title about-title">Online Learning</h5>
                  <p className="card-text about-text">Online learning is revolutionizing the way we acquire knowledge and skills. It offers flexibility, accessibility, and a wealth of resources right at your fingertips.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className=" col second">
            <div className='second-div'>
              <div className="card " style={{ height: '15rem' }}>
                <div className="card-body about-card">
                  <div className="card-img-top about-img">
                    <img src="../images/certificate.png" className='abt-image' alt="..." height={60} width={60} />
                  </div>
                  <h5 className="card-title about-title">Certification</h5>
                  <p className="card-text about-text">Whether you're looking to advance in your career, showcase your proficiency, or open doors to new opportunities,
                    our certification program is tailored to help you achieve your goals.
                  </p>
                </div>
              </div>
              <div className="card " style={{ height: '15rem' }}>
                <div className="card-body about-card">
                  <div className="card-img-top about-img">
                    <img src="../images/rocket.png" className='abt-image' alt="..." height={60} width={60} />
                  </div>
                  <h5 className="card-title about-title">Improvement</h5>
                  <p className="card-text about-text">Get expert guidance from industry-seasoned professionals and earn a recognized certification, setting you apart as a proficient web developer in high demand.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div
          className="cursor-trail"
          style={{
            width: "160px",
            height: "160px",
            backgroundColor: "#461A62",
            borderRadius: "50%",
            position: "fixed",
            top: trailStyle.top,
            left: trailStyle.left,
            zIndex: -1,
            filter: "blur(90px)",
            WebkitFilter: "blur(90px)",
          }}
        ></div>
      </div>
    </>
  )
}

export default Aboutus