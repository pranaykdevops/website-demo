import React from 'react'
import Header from './Header'
import Aboutus from './Aboutus'
import Testimonials from './Testimonials'
import Information from './Information'
import { Footer } from './Footer'
import Navbar from './Navbar'
import CoursesSlider from './Coursescarousel/CoursesSlider'
import Career from './Career'
import Brands from './Brands'


const All = () => {

    return (

        <div>
            <div className='sticky-top'>
                <Navbar />
            </div>
            <Header />
            <Aboutus />
            <Career />
            <CoursesSlider />
            <Testimonials />
            <Brands />
            <Information />
            <div>
                <Footer />
            </div>
        </div>
    )
}

export default All