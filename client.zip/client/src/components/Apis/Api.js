import axios from 'axios'
import apiUrl from '../../config';
const RegisterApi = async (formData) => {
    try {
      const response = await fetch(`${apiUrl}/user/Register`, {
        method: 'POST',
        body: JSON.stringify(formData),
        headers: {
          'Content-Type': 'application/json',
        },
      });
  
      if (response.ok) {
        const data = await response.json();
        return data;
      } else {
        throw new Error('Network response was not ok');
      }
    } catch (error) {
      console.log(error);
    }
  };
  
  const LoginApi = async (details) => {
    try {
      const response = await fetch(`${apiUrl}/user/Login`, {
        method: 'POST',
        body: JSON.stringify(details),
        headers: {
          'Content-Type': 'application/json',
        },
      });
  
      if (response.ok) {
        const data = await response.json();
        return data;
      } else {
        throw new Error('Network response was not ok');
      }
    } catch (error) {
      console.log(error);
    }
  };
  

export { RegisterApi, LoginApi }