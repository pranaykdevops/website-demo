import React from 'react'
import '../css/brands.css';

const Brands = () => {
  return (
    <>
      <div className='row gx-0 justify-content-center brands'>
        <div className='col-lg-6 col-md-6 col-sm-12 brandtext'>
          <div className='brand-brand'>
            <h1 className='brandh1'>Customers & brands love using techu </h1>
            <p className='brandtext-wrap'>
              Discover how TechU can revolutionize your technological landscape.
              Join our community of satisfied customers and partner brands, and experience the TechU difference!

            </p>
          </div>
        </div>
        <div className='col-lg-6 col-md-6 col-sm-12 brand-image'>

          <div className='scroll-container'>
            <div className='scroll-shadow'> </div>
            <div className="scroll-to-left w-100 my-4">
              <div className="content">
                <img src="./images/clients/Rectangle.png" alt="" height="63" />
              </div>
            </div>
            <div className="scroll-to-right w-100 my-4">
              <div className="content">
                <img src="./images/clients/Rectangle1.png" alt="" height="63" />
              </div>
            </div>
            <div className="scroll-to-left w-100 my-4">
              <div className="content">
                <img src="./images/clients/Rectangle2.png" alt="" height="63" />
              </div>
            </div>
          </div>
        </div>
      </div></>
  )
}

export default Brands