import React from 'react'
import '../css/career.css'

const Career = () => {
    return (
        <>
            <div className='row gx-0 career'>
                <div className='col-lg-7 col-md-6 col-sm-12 careertext'>
                    <p className='careerp '>What we do</p>
                    <h1 className='careerh1'>Increase your expertise in planning Career, Job life.</h1>
                    <p className='careertext-wrap'>
                    "Our mission is to empower individuals in elevating their proficiency in career planning and job management."   
                    </p>
                </div>
                <div className='col-lg-5 col-md-6 col-sm-12 career-image'>
                    <img src="../images/wedo-video.png" />
                </div>
            </div>
        </>
    )
}

export default Career