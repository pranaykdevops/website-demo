import React, { useState } from 'react'
import '../css/contact.css'
import axios from 'axios';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { grey, pink } from '@mui/material/colors';
import { EnvelopeOpenFill, HouseAddFill } from 'react-bootstrap-icons';
import { TelephoneFill } from 'react-bootstrap-icons'
import FormHelperText from '@mui/material/FormHelperText';

import Navbar from './Navbar';
import apiUrl from '../config';
import { Footer } from './Footer';
export default function Contact() {
    const formtheme = createTheme({
        palette: {
            primary: {
                main: pink[200],
            },
            secondary: {
                main: grey[500],
            },
        },
    });

    const [details, setDetails] = React.useState({
        name: "",
        email: "",
        mobile: "",
        course: "",
        message: ""
    })
    const [errors, setErrors] = React.useState("")

    const onFormSubmit = (e) => {
        e.preventDefault()
    }
    const [isFieldFocused, setIsFieldFocused] = useState(false);

    const onChangeFormData = (e) => {
        try {
            let name = e.target.name;
            let value = e.target.value;
            if (name === 'mobile') {
                if (value.length > 10) {
                    value = value.slice(0, 10);
                    console.log(value, "value")
                }
            }
            setDetails((ps) => ({ ...ps, [name]: value }))
        } catch (e) {
            console.log(e)
        }
    }

    const onSubmitFormData = async () => {
        try {
            console.log(details);
            const response = await fetch(apiUrl + '/enquiry', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(details),
                credentials: 'omit',
            });
    
            if (response.ok) {
                setDetails({
                    name: "",
                    email: "",
                    mobile: "",
                    course: "",
                    message: ""
                });
    
                console.log(details);
            } else {
                const errorResponse = await response.json();
                console.log(errorResponse);
                setErrors(errorResponse.message);
            }
        } catch (e) {
            console.log(e);
            setErrors(e.response?.data.message);
        }
    }
    
    const courselist = ['MERN STACK', 'MEAN STACK', 'DATA SCIENCE', 'DEVOPS']
    return (
        <>
            <div>
                <div className='sticky-top'>
                    <Navbar />
                </div>
                <div className='contact-mainContainer'>
                    <div className='main row'>
                        <div className='main-contant col-lg-6 col-md-6 col-sm-12'>
                            <h5 className='main-head'>Let’s talk <br />feel free</h5>
                            <p className='contact-text'>We collaborate with thousands of creators, entrepreneurs and complete legends</p>
                            <p className='contact-more'>Get More information</p>
                            <div className='contact-mail  '>
                                <span className='contact-icons'><EnvelopeOpenFill size={25} style={{ color: "C76A97" }} /></span>
                                <p className='contact-infor '>info@techu.com</p>
                            </div>
                            <div className='contact-mail  '>
                                <span className='contact-icons'><TelephoneFill size={25} style={{ color: "C76A97" }} /></span>
                                <p className='contact-infor '>040-40261333</p>
                            </div>
                            <div className='contact-mail  '>
                                <span className='contact-icons'><HouseAddFill size={25} style={{ color: "C76A97" }} /></span>
                                <p className='contact-infor '>#303B Images Capital Park, Madhapur,Hyderabad - 500081</p>
                            </div>

                        </div>
                        <div className='main-form col-lg-6 col-md-6 col-sm-12  '>
                            <div className='mt-4'>
                                {/* <h1>{errors}</h1> */}
                                <div className=' pe-0   mt-5 pb-5'>
                                    <form className='' onSubmit={onFormSubmit}>
                                        <ThemeProvider theme={formtheme}>

                                            <TextField id="outlined-basic" className='fields mt-3 w-100' name='name' value={details.name} onChange={onChangeFormData} onFocus={() => setIsFieldFocused(true)}
                                                onBlur={() => setIsFieldFocused(false)} type='text' label=" Name" variant="outlined" />
                                            <FormHelperText style={{ color: 'red' }}>
                                                {isFieldFocused ? "" : (errors === "please enter the name") ? "Enter a Valid Name" : ""}</FormHelperText>
                                            <TextField id="outlined-basic" className='fields mt-3 w-100 ' name='email' value={details.email} onChange={onChangeFormData} label="E-Mail" type='email' onFocus={() => setIsFieldFocused(true)}
                                                onBlur={() => setIsFieldFocused(false)} variant="outlined" />
                                            <FormHelperText style={{ color: 'red' }}>
                                                {isFieldFocused ? "" : (errors === "Please enter the email") ? "Enter a Valid Email" : ""}</FormHelperText>
                                            <FormHelperText style={{ color: 'red' }}>
                                                {isFieldFocused ? "" : (errors === "Invalid Email") ? "Enter a Valid Email" : ""}</FormHelperText>
                                            <FormHelperText style={{ color: 'red' }}>
                                                {isFieldFocused ? "" : (errors === "You have been already Enrolled") ? "Enter a Valid Email" : ""}</FormHelperText>
                                            <TextField id="outlined-basic" className='fields mt-3 w-100 ' name='mobile' value={details.mobile}
                                                inputProps={{
                                                    maxLength: 10,
                                                }}
                                                onFocus={() => setIsFieldFocused(true)}
                                                onBlur={() => setIsFieldFocused(false)} onChange={onChangeFormData} type='number' label="Moblie" variant="outlined" />
                                            <FormHelperText style={{ color: 'red' }}>
                                                {isFieldFocused ? "" : (errors === "Please Enter Phone Number") ? "Enter a Valid Mobile Number" : ""}</FormHelperText>
                                            <FormHelperText style={{ color: 'red' }}>
                                                {isFieldFocused ? "" : (errors === "Enter valid phone number") ? "Enter a Valid Mobile Number" : ""}</FormHelperText>
                                            <FormControl sx={{ color: 'black' }} className='mt-3 w-100'>

                                                <InputLabel id="demo-simple-select-autowidth-label" className=' w-100'>Course</InputLabel>
                                                <Select
                                                    name="course"
                                                    labelId="demo-simple-select-autowidth-label"
                                                    id="demo-simple-select-autowidth"
                                                    value={details.course}
                                                    onChange={onChangeFormData}
                                                    autoWidth
                                                    label="course"
                                                    onFocus={() => setIsFieldFocused(true)}
                                                    onBlur={() => setIsFieldFocused(false)}
                                                >
                                                    {
                                                        courselist.map((course) => (
                                                            <MenuItem value={course} >{course}</MenuItem>))
                                                    }
                                                </Select>
                                            </FormControl>
                                            <FormHelperText style={{ color: 'red' }}>
                                                {isFieldFocused ? "" : (errors === "Please Select Course") ? "Select a Course" : ""}</FormHelperText>

                                            <TextField id="outlined-basic" className='fields mt-3 w-100' multiline minRows={3} name='message' onChange={onChangeFormData} type='text' label="Message" variant="outlined" />

                                        </ThemeProvider>
                                        <div className='d-flex justify-content-center mt-4 '>
                                            <button className='preview-btn px-5 py-2' onClick={onSubmitFormData}>Submit</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <Footer />
                </div>
            </div>
        </>
    )
}
