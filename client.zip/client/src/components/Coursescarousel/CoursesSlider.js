import React from 'react'
import { Navigation, Pagination, Scrollbar, A11y, Autoplay } from 'swiper/modules';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
// import 'swiper/swiper.min.css'
// import 'swiper/swiper-bundle.min.css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/scrollbar';
import 'swiper/css/autoplay';
import './coursesslider.css'
import SwiperNavButton from './SwiperNavButton';
import { StarFill } from 'react-bootstrap-icons';

const CoursesSlider = () => {
    const courses = [
        {
            image: "../images/mern-image.png",
            title: "MERN STACK",
            duration: "3 month",
            rating: 4.5,
            reviews: 160
        }, {
            image: "../images/MicrosoftTeams-image.png",
            title: "DEVOPS",
            duration: "3 month",
            rating: 4.6,
            reviews: 150
        },
        {
            image: "../images/previewimg.png",
            title: "MEAN STACK",
            duration: "3 month",
            rating: 4.7,
            reviews: 190
        },
        {
            image: "../images/D-Science.png",
            title: "DATA SCIENCE",
            duration: "3 month",
            rating: 4.5,
            reviews: 160
        },
        {
            image: "../images/mern-image.png",
            title: "MERN STACK",
            duration: "3 month",
            rating: 4.8,
            reviews: 120
        },
        {
            image: "../images/previewimg.png",
            title: "MEAN STACK",
            duration: "3 month",
            rating: 4.6,
            reviews: 150
        },
        {
            image: "../images/D-Science.png",
            title: "DATA SCIENCE",
            duration: "3 month",
            rating: 4.5,
            reviews: 170
        },
        {
            image: "../images/MicrosoftTeams-image.png",
            title: "DEVOPS",
            duration: "3 month",
            rating: 4.7,
            reviews: 180
        },
    ]

    return (
        <div className='d-flex justify-content-center courses'>

            <div className='course-slider-container '>
                <div className='courses-slider'>
                    <p className='coursesp '>Courses</p>
                    <h1 className='coursesh1'>Accelerate your career in web development</h1>
                    <p className='coursestext-wrap'>
                    Gain In-Demand Skills: Our curriculum is meticulously crafted to cover the latest web technologies and programming
                     languages, ensuring you're industry-ready from day one.                  </p>
                </div>
                <Swiper

                    modules={[Navigation, Pagination, Scrollbar, A11y, Autoplay]}
                    spaceBetween={50}


                    breakpoints={{
                        640: {
                            slidesPerView: 1,
                        },
                        768: {
                            slidesPerView: 2,
                        },
                        1024: {
                            slidesPerView: 4,
                        },
                    }}
                // className="mySwiper"
                >
                    {
                        courses.map((course) =>
                            <SwiperSlide>
                                <div className='course-slider-card'>
                                    <div className='course-slider-card-image'>
                                        <img src={course.image} alt='' />

                                    </div>
                                    <div className='course-slider-card-content'>
                                        <p className='course-duration'>{course.duration}</p>
                                        <h6 className='course-title'>{course.title}</h6>
                                        <span className='course-rating'><StarFill className='rating-start' size={13.5} />  {course.rating}  |  {course.reviews +"   "+ "reviews"}</span>

                                    </div>

                                </div>

                            </SwiperSlide>

                        )

                    }
                    <div className='slider-button'>
                        <SwiperNavButton />
                    </div>
                </Swiper>

            </div>
        </div>





    )
}

export default CoursesSlider