import React from 'react'

import "../css/footer.css"
import { EnvelopeOpen, Facebook, Instagram, Linkedin, Phone, Telephone, Twitter, Whatsapp } from 'react-bootstrap-icons'
import { Link } from 'react-router-dom'

export const Footer = () => {

    return (

        <div className='container-fluid footer '>
            <div className='m-3'>
                <div className='row ftr py-3 px-5'>
                    <div className='col-12 col-sm-12 col-md-6 col-lg-3  mt-5 footer1'>
                        <img src='../images/Group.png' alt='' style={{ width: '90px' }} />
                        <h5 className="techu" style={{ width: '83.12px' }}>Tech<span style={{ color: 'grey' }} >U</span> </h5>
                        <div className='footer-icons mt-4 w-50'>
                            <a className='a-icons'> <Whatsapp /></a>
                            <a  className='a-icons'> <Linkedin /></a>
                            <a  className='a-icons'><Twitter /></a>
                            <a  className='a-icons'><Facebook /></a>
                            <a href='https://www.instagram.com/techu_by_abilio/' target='_blank' className='a-icons'><Instagram /></a>
                        </div>
                    </div>
                    <div className='col-12 col-sm-12 col-md-6 col-lg-3  mt-5 footer2'>
                        <h2 className=''>SUPPORT</h2>
                        <div className='ft1 pt-2 '>
                            <p>About us</p>
                            <p>FAQ's</p>
                            <p>Newsletters</p>
                            <p>Gallery</p>
                            <p> <Link to='/contact' className='footer-course-links'>Contact Us</Link></p>
                        </div>
                    </div>
                    <div className='col-12 col-sm-12 col-md-6 col-lg-3  mt-5 footer3'>
                        <h2 className=''>COURSES</h2>
                        <div className='ft2 pt-2'>
                            <p> <Link to='/mernstack' className='footer-course-links'>MernStack</Link></p>
                            <p><Link to='/meanstack' className='footer-course-links'>MeanStack</Link></p>
                            <p>  <Link to='/datascience' className='footer-course-links'>DataScience</Link></p>
                            <p>  <Link to='/devops' className='footer-course-links'>Devops</Link></p>

                        </div>
                    </div>
                    <div className='col-12 col-sm-12 col-md-6 col-lg-3  mt-5 footer4 '>
                        <h2 className='w-75'>LOCATION</h2>
                        <div className='ft3 row pt-2 '>
                            <p>#303B Images Capital Park, Madhapur,<br /> Hyderabad - 500081</p>
                            <p className='footer-email'><EnvelopeOpen className='me-3' /> info@techu.com</p>
                            <p className='footer-phone'><Telephone className='me-3' /> 040-40261333</p>
                        </div>
                    </div>
                </div>
            </div>
            <hr className='ms-5' style={{ width: '93%', color: '#fffff' }}></hr>
            <div className=' row gx-0 copyright mt-4 mx-5'>
                <div className=' col-sm-12 col-md-9 col-lg-8 cpyryt ' >
                    <p className='copy-head'>&copy; Copyright 2023 TechU by Abilio IT Solutions Pvt Ltd. All Rights Reserved</p>
                </div>
                <div className=' col-sm-12 col-md-3 col-lg-4 conditions '>
                    <p className='p1'><Link to='/terms' className='pe-2' style={{ color: "white",textDecoration:'none' }}>Terms & Conditions</Link></p>
                    <Link to='/privacy' className='ps-2' style={{ color: "white",textDecoration:'none' }}>Privacy Policy</Link>

                </div>
            </div>
        </div>

    )
}