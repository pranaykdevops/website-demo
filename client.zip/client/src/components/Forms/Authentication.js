import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LoginApi, RegisterApi } from '../Apis/Api';
import '../../css/login.css';
import FormHelperText from '@mui/material/FormHelperText';
import TextField from '@mui/material/TextField';
import { ThemeProvider, createTheme } from '@mui/material';
import { grey, pink } from '@mui/material/colors';
import IconButton from '@mui/material/IconButton';
import InputAdornment from '@mui/material/InputAdornment';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import { PopupContext } from '../../PopupProvider';
import "../../css/popup.css";
import { XCircleFill } from 'react-bootstrap-icons';
import { Box } from '@mui/material';



const Authentication = () => {
    const {
        closePopup3,
        closePopup1,
        openPopup2,
    } = React.useContext(PopupContext);

    const navigate = useNavigate()
    const [changeform, setChangeform] = useState("register");
    const [validationMessage, setValidationMessage] = useState('');
    const [details, setDetails] = useState({
        email: '',
        password: '',
    });
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phonenumber: '',
        password: '',
    });
    const [errors, setErrors] = useState('');
    const [isFieldFocused, setIsFieldFocused] = useState(false);
    const [showPassword, setShowPassword] = useState(false);


    const onChangeFormData = (e) => {
        let name = e.target.name;
        let value = e.target.value;
        if (name === 'phonenumber') {
            value = value.replace(/[^0-9]/g, '')

            value = value.replace(/-/g, '');

            if (value.length > 10) {
                value = value.slice(0, 10);
            }
        }
        setFormData((prevData) => ({ ...prevData, [name]: value }));
    };

    const onChangeLoginData = (e) => {
        let name = e.target.name;
        let value = e.target.value;
        setDetails((prevData) => ({ ...prevData, [name]: value }));
    };

    const onSubmitFormData = async () => {
        
        if (changeform === "register") {
            try {
                const res = await RegisterApi(formData, {
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                    }),
                    credentials: 'omit'
                });
                const responseStatus = res.status;
                const responseValidationMessage = res.data.message;
                if (responseStatus === 200) {
                    setFormData({
                        name: ' ',
                        email: ' ',
                        phonenumber: ' ',
                        password: ' ',
                    });
                    setValidationMessage(responseValidationMessage);
                    const authname= "Register Successful";
                    const authmessage=`You are registered successfully. Please Login`
                    closePopup1();
                    openPopup2(authname,authmessage);
                    closePopup3()
                } else {
                    setValidationMessage("Registration failed. Please try again.");
                }
            } catch (e) {
                console.log(e);
                setValidationMessage(e.response?.data.message || "An error occurred during registration.");
            }
        } else {
           
            try {
                const res = await LoginApi(details, {
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                    }),
                    credentials: 'omit'
                });
                console.log(res.Status,"ress")
                const responseStatus = res.message;
                if (responseStatus === "Login successfull") {
                    setDetails({
                        email: '',
                        password: '',
                    })
                    const authname= "login Successful";
                    const authmessage=`You are successfully LoggedIn.`
                    closePopup1();
                    navigate('/StudentDashboard')
                    closePopup3()
                    localStorage.setItem('userId',res.exist._id)
                    
                } else {
                    setErrors("Login failed. Please check your credentials and try again.");
                }
            } catch (e) {
                console.log(e);
                setErrors(e.response?.data.message || "An error occurred during login.");
            }
        }
    };


    const onSubmit = (e) => {
        e.preventDefault();
    };

    const onFormSubmit = (e) => {
        e.preventDefault();
    };

    let formtheme;

    formtheme = createTheme({
        palette: {
            primary: {
                main: pink[200],
            },
            secondary: {
                main: grey[500],
            },
        },
    });

    return (
        <>
            <div className='popup-container'>
                <div className='popup-body'>
                    <Box>
                        <div className='d-flex justify-content-between'>
                            <span className=" ms-auto" style={{ marginRight: '10px', marginTop: '5px', color: "black" }} onClick={() => { closePopup1() }}> <XCircleFill size={20} /></span>
                        </div>
                    </Box>
                    <div className='row w-100'>
                        <div className="col-lg-6 col-sm-12 signup-main">
                            <div className="loginImg   ">
                                <div className=" loginImg-text p-5 ">
                                    <p className="login-imgText ">People begin to become successful the minute they decide to be</p>
                                </div>
                                <div className="loginImg-img  mt-5 pb-5">
                                    <img className="login-Img" src="../images/object.png" width={'100%'} height={'100%'} alt='' />
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6 col-sm-12">
                            {
                                (changeform == "register") ?
                                    <>
                                        <div className="col-lg-12">
                                            <div className="login-details">
                                                <div className="techu mt-3 ">
                                                    <img className="logo" src="../images/Logo.png" alt="Logo" width={150} />
                                                </div>
                                                <div className="form d-flex justify-content-center ">
                                                    <div className=" ">
                                                        <h5 className='mt-5'>Sign Up</h5>
                                                        <form className="d1 mt-4" onSubmit={onSubmit}>
                                                            <ThemeProvider theme={formtheme}>
                                                                <div className="input-box  ">
                                                                    {/* Name field */}
                                                                    <TextField
                                                                        size="small"
                                                                        className="input-email w-100 form-control"
                                                                        type="text"
                                                                        name="name"
                                                                        label="Name"
                                                                        value={formData.name}
                                                                        variant="outlined"
                                                                        onChange={onChangeFormData}
                                                                        onFocus={() => setIsFieldFocused(true)} // Handle focus event
                                                                        onBlur={() => setIsFieldFocused(false)} // Handle blur event
                                                                    />
                                                                    <FormHelperText style={{ color: 'red' }}>
                                                                        {isFieldFocused ? "" : (validationMessage === 'Please enter the name') ? 'Enter a Valid Name' : ''}
                                                                    </FormHelperText>
                                                                </div>
                                                                <div className="input-box mt-3">
                                                                    <TextField
                                                                        size="small"
                                                                        className="input-email w-100"
                                                                        type="email"
                                                                        name="email"
                                                                        label="Mail ID"
                                                                        variant="outlined"
                                                                        value={formData.email}
                                                                        onChange={onChangeFormData}
                                                                        onFocus={() => setIsFieldFocused(true)} // Handle focus event
                                                                        onBlur={() => setIsFieldFocused(false)} // Handle blur event
                                                                    />
                                                                    <FormHelperText style={{ color: 'red' }}>
                                                                        {isFieldFocused ? "" : (validationMessage === 'Please enter the email') ? 'Enter a Valid Email' : ''}
                                                                    </FormHelperText>
                                                                    <FormHelperText style={{ color: 'red' }}>
                                                                        {isFieldFocused ? "" : (validationMessage === 'Email is not valid') ? 'Enter a Valid Email' : ''}
                                                                    </FormHelperText>
                                                                    <FormHelperText style={{ color: 'red' }}>
                                                                        {isFieldFocused ? "" : (validationMessage === 'You have been already registered') ? 'Enter a Valid Email' : ''}
                                                                    </FormHelperText>
                                                                </div>
                                                                <div className="input-box mt-3">
                                                                    <TextField
                                                                        size="small"
                                                                        className="input-email w-100"
                                                                        type="number"
                                                                        name="phonenumber"
                                                                        label="Phone Number"
                                                                        variant="outlined"
                                                                        onChange={onChangeFormData}
                                                                        value={formData.phonenumber}
                                                                        inputProps={{
                                                                            maxLength: 10,
                                                                        }}
                                                                        onFocus={() => setIsFieldFocused(true)} // Handle focus event
                                                                        onBlur={() => setIsFieldFocused(false)} // Handle blur event
                                                                    />
                                                                    <FormHelperText style={{ color: 'red' }}>
                                                                        {isFieldFocused ? "" : (validationMessage === "Please enter the mobile number") ? "Enter a valid Mobile Number" : ""}
                                                                    </FormHelperText>
                                                                    <FormHelperText style={{ color: 'red' }}>
                                                                        {isFieldFocused ? "" : (validationMessage === 'Please enter the correct Number ') ? 'Enter a Valid Mobile Number' : ''}
                                                                    </FormHelperText>
                                                                </div>
                                                                <div className="input-box mt-3 ">
                                                                    <TextField
                                                                        size="small"
                                                                        className="input-email w-100 form-control"
                                                                        type={showPassword ? 'text' : "password"}
                                                                        name="password"
                                                                        label="Create Password"
                                                                        id="input-password"
                                                                        value={formData.password}
                                                                        variant="outlined"
                                                                        onChange={onChangeFormData}
                                                                        onFocus={() => setIsFieldFocused(true)} // Handle focus event
                                                                        onBlur={() => setIsFieldFocused(false)} // Handle blur event
                                                                        InputProps={{
                                                                            endAdornment: (
                                                                                <InputAdornment position="end">
                                                                                    <IconButton
                                                                                        onClick={() => setShowPassword(!showPassword)}
                                                                                        edge="end"
                                                                                    >
                                                                                        {showPassword ? <VisibilityOff /> : <Visibility />}
                                                                                    </IconButton>
                                                                                </InputAdornment>
                                                                            ),
                                                                        }}
                                                                    />
                                                                    <FormHelperText style={{ color: 'red' }}>{(validationMessage === "Please enter the password") ? "Enter a Valid Password" : ""}</FormHelperText>
                                                                    <FormHelperText style={{ color: 'red' }}>
                                                                        {isFieldFocused ? "" : (validationMessage === 'Password should be at least of length 8') ? 'Please ensure that your password contains at least 8 characters' : ''}
                                                                    </FormHelperText>
                                                                </div>
                                                            </ThemeProvider>
                                                        </form>
                                                        <div className="d-flex justify-content-evenly mt-2">
                                                            <button className="login-btn  mt-4   px-4 py-2" onClick={onSubmitFormData}>
                                                                Sign Up
                                                            </button>                                        
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="d-flex justify-content-center mt-2">
                                                    <p className="signup mt-3">
                                                        Already have an account?
                                                        <span className="signup-btn "
                                                            onClick={() => {
                                                                setChangeform("login")
                                                            }} style={{ border: "none", color: "#C67A97", cursor: "pointer" }}>Login
                                                        </span>
                                                    </p>
                                                </div>
                                            </div> 
                                        </div>
                                    </>
                                    :
                                    <>
                                        <div className="col-lg-12 col-sm-12 login-main">
                                            <div className="login-details">
                                                <div className="techu py-3">
                                                    <img className="logo" src="../images/Logo.png" alt="Logo" width={150} />
                                                </div>
                                                <div className="form d-flex justify-content-center ">
                                                    <div className='login-page'>
                                                        <h5 className="login-heading mt-5">Login</h5>
                                                        <p className="form-p pt-2">Enter your account details</p>
                                                        <form className="d1" onSubmit={onFormSubmit}>
                                                            <ThemeProvider theme={formtheme}>
                                                                <div className="input-box ">
                                                                    <TextField
                                                                        size="small"
                                                                        className="input-email w-100"
                                                                        type="email"
                                                                        value={details.email}
                                                                        name="email"
                                                                        label='Mail ID'
                                                                        onChange={onChangeLoginData}
                                                                        variant="outlined"
                                                                        onFocus={() => setIsFieldFocused(true)}
                                                                        onBlur={() => setIsFieldFocused(false)}
                                                                    />
                                                                    <FormHelperText style={{ color: 'red' }}>
                                                                        {isFieldFocused ? "" : (errors === 'Please enter your email') ? "Enter a Valid Email" : ""}</FormHelperText>
                                                                    <FormHelperText style={{ color: 'red' }}>
                                                                        {isFieldFocused ? "" : (errors === 'You have not registered, please sign up') ? "You have not registered, please register" : ""}</FormHelperText>
                                                                </div>
                                                                <div className="input-box my-3">
                                                                    <TextField
                                                                        size="small"
                                                                        className="input-email w-100"
                                                                        type={showPassword ? 'text' : 'password'}
                                                                        name="password"
                                                                        value={details.password}
                                                                        id="input-password"
                                                                        label="Password"
                                                                        variant="outlined"
                                                                        onChange={onChangeLoginData}
                                                                        onFocus={() => setIsFieldFocused(true)}
                                                                        onBlur={() => setIsFieldFocused(false)}
                                                                        InputProps={{
                                                                            endAdornment: (
                                                                                <InputAdornment position="end">
                                                                                    <IconButton
                                                                                        onClick={() => setShowPassword(!showPassword)}
                                                                                        edge="end"
                                                                                    >
                                                                                        {showPassword ? <VisibilityOff /> : <Visibility />}
                                                                                    </IconButton>
                                                                                </InputAdornment>
                                                                            ),
                                                                        }}
                                                                    />
                                                                    <FormHelperText style={{ color: 'red' }}>
                                                                        {isFieldFocused ? "" : (errors === 'Please enter your password') ? "Enter a Valid Password" : ""}</FormHelperText>
                                                                    <FormHelperText style={{ color: 'red' }}>
                                                                        {isFieldFocused ? "" : (errors === 'Incorrect password') ? "Incorrect password" : ""}</FormHelperText>
                                                                </div>
                                                            </ThemeProvider>
                                                            <Link className="forgot" to="/forgot-password" style={{ color: '#C76A97', }}>
                                                                Forgot Password?
                                                            </Link>
                                                        </form>
                                                        <div className="ps-5">
                                                            <button className="login-btn  mt-4 ms-5  px-4 py-1" onClick={onSubmitFormData}>
                                                                Login
                                                            </button>                                                                                                               
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="d-flex justify-content-center mt-4 ">
                                                    <p className="signup">
                                                        Don’t have an account?<a className="signup-btn " style={{ color: '#C76A97' }}>
                                                            {' '}
                                                            <span onClick={() => {
                                                                setChangeform("register")
                                                            }} style={{ border: "none", color: "#C67A97", cursor: "pointer", fontSize: "20px" }}>Sign Up</span>
                                                        </a>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </>
                            }
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Authentication;
