import * as React from 'react';
import TextField from '@mui/material/TextField';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { grey, pink } from '@mui/material/colors';
import axios from 'axios';
import FormHelperText from '@mui/material/FormHelperText';
import '../../css/preview.css'
import apiUrl from '../../config';

const Enroll = (props) => {
    // console.log(batch,"internshipbatchdetails")
    const { batch } = props
    // console.log(batch,"enrollform")
    // console.log(batch,'ef4ygb3wfeh')
    // console.log(batch[0]?._id,"internshipbatchdetails")
    const [isFieldFocused, setIsFieldFocused] = React.useState(false);
    const [details, setDetails] = React.useState({
        name: "",
        email: "",
        mobile: "",
        passOutYear: "",
        internshipId:batch
    })
    const [errors, setErrors] = React.useState("")
    const [enrollmentCount, setEnrollmentCount] = React.useState(0);


    const onFormSubmit = (e) => {
        e.preventDefault()
    }

    const onChangeFormData = (e) => {
        try {
            let name = e.target.name;
            let value = e.target.value;
            setDetails((ps) => ({ ...ps, [name]: value }))
        } catch (e) {
            console.log(e)
        }
    }

    const onSubmitFormData = async () => {
        console.log(details);
        try {
            const response = await fetch(apiUrl + '/Internship/addinternship', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(details),
                credentials: 'omit',
            });
    
            if (response.ok) {
                const data = await response.json();
                if (data.status === 200) {
                    setEnrollmentCount(enrollmentCount.length);
                }
                setDetails({
                    name: "",
                    email: "",
                    mobile: "",
                    passOutYear: ""
                });
            } else {
                const errorResponse = await response.json();
                console.log(errorResponse);
                setErrors(errorResponse.message);
            }
        } catch (e) {
            console.log(e);
            setErrors(e.response?.data.message);
        }
    }
    
    const allInternshipEnrolls = async () => {
        try {
            const response = await fetch(apiUrl + '/Internship/allinternshipbatch');
            if (response.ok) {
                const data = await response.json();
                setEnrollmentCount(data.length);
            } else {
                console.log('Error:', response.status);
            }
        } catch (error) {
            console.log(error);
        }
    }
    
    const formtheme = createTheme({
        palette: {
            primary: {
                main: pink[200],
            },
            secondary: {
                main: grey[500],
            },
        },
    });

    const formatEnrollmentCount = (count) => {
        return count.toString().padStart(3, '0');
    }

    allInternshipEnrolls()

    return (
        <>
            <center>
               <div className=''>
               <div className=''>
                    <h1 className='internship-regi'>
                        {formatEnrollmentCount(enrollmentCount).split('').map((number, index) => (
                            <span key={index} className={`number-${index}`}>
                                {number}
                            </span>
                        ))}
                    </h1>
                    <h6>Students Registered</h6>
                </div>
                <div className='preview-form  p-3 w-100' style={{ backgroundColor: "white" }}>
                    <form className='' onSubmit={onFormSubmit}>
                        <ThemeProvider theme={formtheme}>
                            <TextField id="outlined-basic" className='fields mt-3 w-100' size='small' name='name' value={details.name} onChange={onChangeFormData} onFocus={() => setIsFieldFocused(true)}
                                onBlur={() => setIsFieldFocused(false)} type='text' label=" Name" variant="outlined" />
                            <FormHelperText style={{ color: 'red' }}>
                                {isFieldFocused ? "" : (errors === "please enter the name") ? "Enter a Valid Name" : ""}</FormHelperText>
                            <TextField id="outlined-basic" size='small' className='fields mt-3 w-100 ' name='email' value={details.email} onChange={onChangeFormData} label="E-Mail" type='email' onFocus={() => setIsFieldFocused(true)}
                                onBlur={() => setIsFieldFocused(false)} variant="outlined" />
                            <FormHelperText style={{ color: 'red' }}>
                                {isFieldFocused ? "" : (errors === "Please enter the email") ? "Enter a Valid Email" : ""}</FormHelperText>
                            <FormHelperText style={{ color: 'red' }}>
                                {isFieldFocused ? "" : (errors === "Invalid Email") ? "Enter a Valid Email" : ""}</FormHelperText>
                            <FormHelperText style={{ color: 'red' }}>
                                {isFieldFocused ? "" : (errors === "You have been already Enrolled") ? "Enter a Valid Email" : ""}</FormHelperText>
                            <TextField id="outlined-basic" size='small' className='fields mt-3 w-100 ' name='mobile' value={details.mobile}
                                inputProps={{
                                    maxLength: 10,
                                }}
                                onFocus={() => setIsFieldFocused(true)}
                                onBlur={() => setIsFieldFocused(false)} onChange={onChangeFormData} type='number' label="Moblie" variant="outlined" />
                            <FormHelperText style={{ color: 'red' }}>
                                {isFieldFocused ? "" : (errors === "Please Enter Phone Number") ? "Enter a Valid Mobile Number" : ""}</FormHelperText>
                            <FormHelperText style={{ color: 'red' }}>
                                {isFieldFocused ? "" : (errors === "Enter valid phone number") ? "Enter a Valid Mobile Number" : ""}</FormHelperText>
                            <TextField id="outlined-basic" type='number' label='Year of Passing' size='small' className='fields mt-3 w-100' name='passOutYear' value={details.passOutYear} onChange={onChangeFormData} onFocus={() => setIsFieldFocused(true)}
                                onBlur={() => setIsFieldFocused(false)} variant="outlined" />
                            <FormHelperText style={{ color: 'red' }}>
                                {isFieldFocused ? "" : (errors === "Please Enter PassOutYear") ? "Enter Pass Out Year" : ""}</FormHelperText>
                        </ThemeProvider>
                        <div>
                        </div>
                        <div className='d-flex justify-content-center mt-4 '>
                            <button className='preview-btn px-5 py-2' onClick={onSubmitFormData}>Submit</button>
                        </div>
                    </form>
                </div>
               </div>
            </center>
        </>
    )
}

export default Enroll