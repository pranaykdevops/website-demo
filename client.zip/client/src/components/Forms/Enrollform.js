import * as React from 'react';
import TextField from '@mui/material/TextField';
import { RadioGroup, FormControlLabel, Radio } from '@mui/material';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import FormControl from '@mui/material/FormControl';
import { grey, pink } from '@mui/material/colors';
import axios from 'axios';
import FormHelperText from '@mui/material/FormHelperText';
import '../../css/preview.css'
import "../../css/popup.css";
import { XCircleFill } from 'react-bootstrap-icons';
import { FormLabel } from 'react-bootstrap';
import apiUrl from '../../config';
import { PopupContext } from '../../PopupProvider';
import Authentication from './Authentication';

const Enrollform = ({ batch }) => {

    const {
        closePopup3,
        openPopup1,
        openPopup4,
        closePopup1,
        isPopup1Open
    } = React.useContext(PopupContext);

    const { timing, trainer, startdate, title } = batch;

    const [details, setDetails] = React.useState({
        firstname: "",
        lastname: "",
        email: "",
        phonenumber: "",
        course: title,
        trainer: trainer,
        timing: timing,
        startdate: startdate,
        mode: "offline",
        userid: localStorage.getItem("userId"),
        batches: batch._id
    })
    const [errors, setErrors] = React.useState("")
    const [isFieldFocused, setIsFieldFocused] = React.useState(false);

    const onFormSubmit = (e) => {
        e.preventDefault()
    }

    const onChangeFormData = (e) => {
        try {
            let name = e.target.name;
            let value = e.target.value;
            if (name === 'phonenumber') {
                if (value.length > 10) {
                    value = value.slice(0, 10);
                    console.log(value, "value")
                }
            }
            setDetails((ps) => ({ ...ps, [name]: value }))
        } catch (e) {
            console.log(e)
        }
    }
    const onSubmitFormData = async () => {
        try {
            const response = await fetch(apiUrl + '/Enroll', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(details),
                credentials: 'omit',
            });
    
            if (response.ok) {
                const data = await response.json();
                setDetails({
                    firstname: "",
                    lastname: "",
                    email: "",
                    phonenumber: "",
                    course: title,
                    trainer: trainer,
                    timing: timing,
                    startdate: startdate,
                    mode: "offline"
                });
    
                if (data.message === "Enrolled Successfully") {
                    const coursename = title;
                    const coursemessage = `Your registration for the ${title} course has been confirmed successfully. Our team will be in touch with you shortly`;
                    closePopup3();
                    openPopup4(coursename, coursemessage);
                }
            } else {
                const errorResponse = await response.json();
                console.log(errorResponse);
                setErrors(errorResponse.message);
            }
        } catch (e) {
            console.log(e);
            setErrors(e.response?.data.message);
        }
    }
    

    const formtheme = createTheme({
        palette: {
            primary: {
                main: pink[200],
            },
            secondary: {
                main: grey[500],
            },
        },
    });

    return (
        <>
            <div className="popup-container">
                <div className="popup-body p-2  ">
                    <div className='d-flex justify-content-between'>
                        <h3 className='sub-heading'>Enroll Now </h3>
                        <span onClick={() => { closePopup3() }}> <XCircleFill size={20} /></span>
                    </div>
                    <div className='text-start'>
                        <h3 >Explore Our Courses</h3>
                        <span>"Unlock Your Potential Today"</span>
                    </div>
                    <center>
                        <div className='preview-form my-2 p-2 w-100 '>
                            <form className='' onSubmit={onFormSubmit} >
                                <ThemeProvider theme={formtheme}>
                                    <div className='enrol-fields '>
                                        <div className='field-input'>
                                            <TextField id="outlined-basic" size="small" className='fields  m-1 w-100' name='firstname' value={details.firstname} onChange={onChangeFormData} type='text' label="First Name" variant="outlined" onFocus={() => setIsFieldFocused(true)}
                                                onBlur={() => setIsFieldFocused(false)} />
                                            <FormHelperText style={{ color: 'red' }}>
                                                {isFieldFocused ? "" : (errors === "please enter the name") ? "Enter a valid name" : ""}</FormHelperText>
                                        </div>
                                        <div className='field-input'>
                                            <TextField id="outlined-basic" size="small" className='fields m-1  w-100' name='lastname' value={details.lastname} onFocus={() => setIsFieldFocused(true)}
                                                onBlur={() => setIsFieldFocused(false)} onChange={onChangeFormData} type='text' label="Last Name" variant="outlined" />
                                            <FormHelperText style={{ color: 'red' }}>
                                                {isFieldFocused ? "" : (errors === "please enter the last name") ? "Enter a valid name" : ""}</FormHelperText>
                                        </div>
                                    </div>
                                    <div className='enrol-fields  '>
                                        <div className='field-input'>
                                            <TextField id="outlined-basic" size="small" className='fields m-1 w-100 ' name='phonenumber' onChange={onChangeFormData} value={details.phonenumber}
                                                inputProps={{
                                                    maxLength: 10,
                                                }}
                                                onFocus={() => setIsFieldFocused(true)}
                                                onBlur={() => setIsFieldFocused(false)} type='number' label="Phone Number" variant="outlined" />
                                            <FormHelperText style={{ color: 'red' }}>
                                                {isFieldFocused ? "" : (errors === "Please Enter Phone Number") ? "Enter a valid number" : ""}</FormHelperText>
                                            <FormHelperText style={{ color: 'red' }}>
                                                {isFieldFocused ? "" : (errors === "Enter valid phone number") ? "Enter a valid Mobile Number" : ""}</FormHelperText>
                                        </div>
                                        <div className='field-input'>
                                            <TextField id="outlined-basic" size="small" className='fields m-1 w-100 ' name='email' value={details.email}
                                                onFocus={() => setIsFieldFocused(true)}
                                                onBlur={() => setIsFieldFocused(false)} onChange={onChangeFormData} label="Mail ID" type='email' variant="outlined" />
                                            <FormHelperText style={{ color: 'red' }}>
                                                {isFieldFocused ? "" : (errors === "Please enter the email") ? "Enter a valid email" : ""}</FormHelperText>
                                            <FormHelperText style={{ color: 'red' }}>
                                                {isFieldFocused ? "" : (errors === "Invalid Email") ? "Enter a valid email" : ""}</FormHelperText>
                                            <FormHelperText style={{ color: 'red' }}>
                                                {isFieldFocused ? "" : (errors === "You been already Enrolled") ? "Enter a valid email" : ""}</FormHelperText>
                                        </div>
                                    </div>
                                    <hr />
                                    <div className=' d-flex flex-column'>
                                        <TextField id="outlined-basic" size='small' className='fields m-1 w-50 ' name="course" onFocus={() => setIsFieldFocused(true)}
                                            onBlur={() => setIsFieldFocused(false)} onChange={onChangeFormData} type='text' value={title} label="" variant="outlined" />
                                        <FormControl>
                                            <FormLabel className='classmode mt-3' id="demo-radio-buttons-group-label">Course mode</FormLabel>
                                            <RadioGroup
                                                row
                                                aria-labelledby="demo-row-radio-buttons-group-label"
                                                defaultValue="offline"
                                                name="mode"
                                                onChange={onChangeFormData}
                                            >
                                                <FormControlLabel value="online" size='small' control={<Radio />} label="Online" />
                                                <FormControlLabel value="offline" size='small' control={<Radio />} label="Offline" />
                                            </RadioGroup>
                                        </FormControl>
                                    </div>
                                    <div className='d-flex gap-3 '>
                                        <TextField id="outlined-basic" size="small" className='fields mt-3 w-50 ' name='trainer' disabled onChange={onChangeFormData} value={trainer} type='text' label="trainer" variant="outlined" />
                                        <TextField id="outlined-basic" size="small" className='fields mt-3 w-50 ' name='' disabled defaultValue="English" label="language" type='text' variant="outlined" />
                                    </div>
                                    <div className='d-flex gap-3'>
                                        <TextField id="outlined-basic" size="small" className='fields mt-3 w-50 ' name='timing' disabled onChange={onChangeFormData} value={timing} type='text' label="timing" variant="outlined" />
                                        <TextField id="outlined-basic" size="small" className='fields mt-3 w-50 ' name='' disabled onChange={onChangeFormData} value={startdate} type='text' label="Start Date" variant="outlined" />
                                    </div>
                                </ThemeProvider>
                                <div className='enroll-bottom my-3 w-100' >To proceed with enrollment, kindly complete the registration process
                                    <span onClick={() => openPopup1()} style={{ color: "#C67A97", cursor: "pointer" }}> Register here</span>
                                    {isPopup1Open && <Authentication onClick={() => closePopup1()} />}
                                </div>
                                <div className='d-flex justify-content-center mt-4 '>
                                    <button className='preview-btn ' onClick={onSubmitFormData}>Submit</button>
                                </div>
                            </form>
                        </div>
                    </center>
                </div>
            </div>
        </>
    )
}

export default Enrollform