import React from 'react'
import { useState } from "react";
import {  useNavigate } from "react-router-dom";
import axios from 'axios'
import '../../css/login.css'
import apiUrl from '../../config';


export default function ForgotPassword() {
    const [email, setEmail] = useState()
    const navigate = useNavigate()

    const handleSubmit = async () => {
        try {
            const response = await fetch(apiUrl + '/user/forgot-password', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email }),
                credentials: 'omit',
            });
    
            if (response.ok) {
                const data = await response.json();
                if (data.Status === "Success") {
                    navigate('/login');
                }
            } else {
                console.log('Error:', response.status);
            }
        } catch (err) {
            console.log(err);
        }
    }
    

    const onFormSubmit = (e) => {
        e.preventDefault();
    };
    return (
        <div className=" d-flex justify-content-center align-items-center  " >
            <div className="forgot-password bg-white  rounded " style={{ boxShadow: ' rgba(67, 71, 85, 0.27) 0px 0px 0.25em, rgba(90, 125, 188, 0.05) 0px 0.25em 1em' }}>
                <h4>Forgot Password</h4>
                <form onSubmit={onFormSubmit}>
                    <div className="mb-3">
                        <label htmlFor="email">
                            <strong>Gmail</strong>
                        </label>
                        <input
                            type="email"
                            placeholder="Enter Gmail"
                            autoComplete="off"
                            name="email"
                            className="form-control rounded-0"
                            onChange={(e) => setEmail(e.target.value)}
                        />
                    </div>
                    <button type="submit" className="btn  w-100 rounded-0" onClick={handleSubmit} style={{ backgroundColor: "#C76A97", color: "#ffffff" }}>
                        Send
                    </button>
                </form>
            </div>
        </div>
    )
}