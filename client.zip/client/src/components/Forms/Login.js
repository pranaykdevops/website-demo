import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ChevronLeft } from 'react-bootstrap-icons';
import { LoginApi } from '../Apis/Api';
import TextField from '@mui/material/TextField'; 
import FormHelperText from '@mui/material/FormHelperText';
import { ThemeProvider, createTheme } from '@mui/material';
import { grey, pink } from '@mui/material/colors';
import '../../css/login.css';

const Login = () => {

  
  const navigate = useNavigate();

  const [details, setDetails] = useState({
    email: '',
    password: '',
  });

  const [errors, setErrors] = useState('');

  const onFormSubmit = (e) => {
    e.preventDefault();
  };
  const formtheme = createTheme({
    palette: {
        primary: {
            main: pink[200],
        },
        secondary: {
            main: grey[500],
        },
    },
});

  const onChangeFormData = (e) => {
    try {
      let name = e.target.name;
      let value = e.target.value;
      setDetails((prevDetails) => ({ ...prevDetails, [name]: value }));
    } catch (e) {
      console.log(e);
    }
  };

  const onSubmitFormData = async () => {
    try {
      const res = await LoginApi(details);
    } catch (e) {
      console.log(e);
      setErrors(e.response?.data.message);
    }
  };

  return (
    <>
      <div className="main row gx-0">
        <div className="col-lg-6 col-sm-12">
          <div className="login-details">
            <div className="back ">
              <h2>
                {' '}
                <ChevronLeft className="icon" size={20} />{' '}
                <Link className="back-link" to="/">
                  {' '}
                  Back
                </Link>{' '}
              </h2>
            </div>
            <div className="techu ">
              <img className="logo" src="../images/Logo.png" alt="Logo"  width={150}/>
            </div>
            <div className="form d-flex justify-content-center ">
              <div>
                <h5 className="login-heading">Login</h5>
                <p className="form-p pt-2">Enter your account details</p>
                <form className="d1" onSubmit={onFormSubmit}>
                <ThemeProvider theme={formtheme}>
                  <div className="input-box ">
                    {/* <Envelope style={{ color: '#C76A97' }} /> */}
                    <TextField
                      className="input-email "
                      type="email"
                      placeholder='E-mail'
                      name="email"
                      onChange={onChangeFormData}
                      size="small"
                      variant="outlined"
                    />
                    <FormHelperText style={{ color: 'red' }}>{(errors === 'Please enter your email') ? "Enter a Valid Email" : ""}</FormHelperText>
                    <FormHelperText style={{ color: 'red' }}>{(errors === 'You have not registered, please sign up') ? "You have not registered, please register" : ""}</FormHelperText>
                  </div>

                  <div className="input-box ">
                    {/* <Lock style={{ color: '#C76A97' }} /> */}
                    <TextField
                      className="input-pwd "
                      type="password"
                      placeholder="Password"
                      name="password"
                      onChange={onChangeFormData}
                      size="small"
                      variant="outlined"
                    />
                    <FormHelperText style={{ color: 'red' }}>{(errors === 'Please enter your password') ? "Enter a Valid Password" : ""}</FormHelperText>
                    <FormHelperText style={{ color: 'red' }}>{(errors === 'Incorrect password') ? "Incorrect password" : ""}</FormHelperText>
                  </div>
                  <Link className="forgot" to="/forgot-password" style={{ color: '#C76A97' }}>
                    Forgot Password?
                  </Link>
                  </ThemeProvider>
                </form>
                <div className="d-flex justify-content-evenly">
                  <button className="login-btn    px-5 py-2" onClick={onSubmitFormData}>
                    Login
                  </button>
                </div>
              </div>
            </div>

            <div className="d-flex justify-content-center  ">
              <p className="signup">
                Don’t have an account?<a className="signup-btn"  style={{ color: '#C76A97' }}>
                  {' '}
                  <Link className="signup-link" to="/signup">
                   Sign Up
                  </Link>
                </a>
              </p>
            </div>
          </div>
        </div>

        <div className="col-lg-6 col-sm-12">
          <div className="loginImg   ">
            <div className=" loginImg-text pt-5">
              <p className="login-imgText m-3  ">People begin to become successful the minute they decide to be</p>
            </div>
            <div className="loginImg-img ">
              <img className="login-Img" src="../images/object.png" width={'100%'} />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;
