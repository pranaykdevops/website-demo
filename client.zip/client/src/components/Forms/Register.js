import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { RegisterApi } from '../Apis/Api';
import { ChevronLeft } from 'react-bootstrap-icons';
import '../../css/login.css';
import FormHelperText from '@mui/material/FormHelperText';
import TextField from '@mui/material/TextField';
import { ThemeProvider, createTheme } from '@mui/material';
import { grey, pink } from '@mui/material/colors';

const Register = () => {


  const [validationMessage, setValidationMessage] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phonenumber: '',
    password: '',
  });

  const onChangeFormData = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const onSubmitFormData = async () => {
    try {
      const res = await RegisterApi(formData);
      // if (validationMessage === "success") {
      //   navigate('/Register')
      // } else {
      //   navigate('/home')
      // }
    } catch (e) {
      console.log(e);
      setValidationMessage(e.response?.data.message);
    }
  };
  const formtheme = createTheme({
    palette: {
        primary: {
            main: pink[200],
        },
        secondary: {
            main: grey[500],
        },
    },
});
  const onSubmit = (e) => {
    e.preventDefault();
  };

  return (
    <div>
      <div className="main row gx-0 ">
        <div className="col-lg-6">
          <div className="login-details">
            <div className="back ">
              <h2>
                {' '}
                <ChevronLeft className="icon" size={20} />{' '}
                <Link to="/" className='back-link' style={{ color: 'black', textDecorationLine: 'none' }}>
                  Back
                </Link>
              </h2>
            </div>
            <div className="techu">
              <img className="logo" src="../images/Logo.png" alt="Logo" width={150}/>
            </div>
            <div className="form d-flex justify-content-center ">
              <div className=" form-div">
                <h5 className='signup-name'>Sign Up</h5>
                <form className="signup-form" onSubmit={onSubmit}>
                <ThemeProvider theme={formtheme}>
                  <div className="input-box  ">
                    <TextField
                      className="input-email  "
                      type="text"
                      name="name"
                      label="Name"
                      size="small"
                      variant="outlined"
                      onChange={onChangeFormData}
                    />
                    <FormHelperText style={{ color: 'red' }}>
                      {validationMessage === 'Please enter the name' ? 'Enter a Valid Name' : ''}
                    </FormHelperText>
                  </div>
                  <div className="input-box ">
                    <TextField
                      className="input-email "
                      type="email"
                      name="email"
                      label="E-Mail"
                      size="small"
                      variant="outlined"
                      onChange={onChangeFormData}
                    />
                    <FormHelperText style={{ color: 'red' }}>
                      {validationMessage === 'Please enter the email' ? 'Enter a Valid Email' : ''}
                    </FormHelperText>
                    <FormHelperText style={{ color: 'red' }}>
                      {validationMessage === 'Email is not valid' ? 'Enter a Valid Email' : ''}
                    </FormHelperText>
                    <FormHelperText style={{ color: 'red' }}>
                      {validationMessage === 'You have been already registered' ? 'Enter a Valid Email' : ''}
                    </FormHelperText>
                  </div>
                  <div className="input-box ">
                    <TextField
                      className="input-email "
                      type="text"
                      name="phonenumber"
                      label="Mobile Number"
                      size="small"
                      variant="outlined"
                      onChange={onChangeFormData}
                    />
                    <FormHelperText style={{ color: 'red' }}>{(validationMessage === "Please enter the mobile number") ? "Enter a valid Mobile Number" : ""}</FormHelperText>

                    <FormHelperText style={{ color: 'red' }}>
                      {validationMessage === 'Please enter the correct Number ' ? 'Enter a Valid Mobile Number' : ''}
                    </FormHelperText>
                  </div>
                  <div className="input-box  ">
                    <TextField
                      className="input-pwd "
                      type="password"
                      name="password"
                      label="Password"
                      size="small"
                      variant="outlined"
                      onChange={onChangeFormData}
                    />
                    <FormHelperText style={{ color: 'red' }}>{(validationMessage === "Please enter the password") ? "Enter a Valid Password" : ""}</FormHelperText>


                    <FormHelperText style={{ color: 'red' }}>
                      {validationMessage === 'Password should be at least of length 8' ? 'Please ensure that your password contains at least 8 characters' : ''}
                    </FormHelperText>
                  </div>
                  </ThemeProvider>
                </form>
                <div className="d-flex justify-content-center">
                  <button className="login-btn  px-4 py-2" onClick={onSubmitFormData}>
                    Sign Up
                  </button>
                </div>
              </div>
            </div>
            <div className="d-flex justify-content-center ">
              <p className="signup ">
                Already have an account?
                <span className="signup-btn ps-2">
                  <Link to="/login" style={{ color: '#C76A97', textDecorationLine: 'none' }}>
                    Login
                  </Link>
                </span>
              </p>
            </div>
          </div>
        </div>
        <div className="col-lg-6">
          <div className="loginImg  ">
            <div className=" loginImg-text  pt-5 ">
              <p className="login-imgText m-3 ">People begin to become successful the minute they decide to be</p>
            </div>
            <div className="loginImg-img  ">
              <img className="login-Img " src="../images/object.png" alt="Object" width={'100%'} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
