import React from 'react'
import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import axios from 'axios'
import '../../css/login.css'
import apiUrl from '../../config';

export default function ResetPassword() {
  const [password, setPassword] = useState()
  const navigate = useNavigate()
  const { id, token } = useParams()

  fetch.defaults.withCredentials = true;


const handleSubmit = async () => {
    try {
        const response = await fetch(apiUrl + `/user/reset-password/${id}/${token}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ password }),
            credentials: 'omit',
        });

        if (response.ok) {
            const data = await response.json();
            if (data.Status === "Success") {
                navigate('/login');
            }
        } else {
            console.log('Error:', response.status);
        }
    } catch (err) {
        console.log(err);
    }
}


  const onFormSubmit = (e) => {
    e.preventDefault();
  };
  return (
    <div className="d-flex justify-content-center align-items-center bg-secondary ">
      <div className="forgot-password bg-white p-3 rounded " style={{ boxShadow: ' rgba(67, 71, 85, 0.27) 0px 0px 0.25em, rgba(90, 125, 188, 0.05) 0px 0.25em 1em' }}>
        <h4>Reset Password</h4>
        <form onSubmit={onFormSubmit}>
          <div className="mb-3">
            <label htmlFor="email">
              <strong>New Password</strong>
            </label>
            <input
              type="password"
              placeholder="Enter Password"
              autoComplete="off"
              name="password"
              className="form-control rounded-0"
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button type="submit" className="btn  w-100 rounded-0" onClick={handleSubmit} style={{ backgroundColor: "#C76A97", style: "#ffffff" }}>
            Update
          </button>
        </form>

      </div>
    </div>
  )
}