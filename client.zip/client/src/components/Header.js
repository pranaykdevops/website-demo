import React from 'react'
import '../css/header.css'
import Authentication from './Forms/Authentication';
import { PopupContext } from '../PopupProvider';




const Header = () => {
    const {
        openPopup1,
        isPopup1Open
      } = React.useContext(PopupContext);

    return (
        <>

            <div className=' row gx-0 main-courses ' >
                <div className='col-lg-6 col-sm-12 coures-heading'>
                    <div className='heading'>
                        <div className='content '>
                            <p className='leader'>The Leader in Online Learning</p>
                            <span><h1 className='master'>Master the Skills to  <br />  <span>Drive your Career.</span></h1></span>
                            <ul className='lists'>
                                <li>Access more then 10+ online courses.</li>
                                <li>Learn with experts from Indias-leading universities.</li>
                                <li>Learn the high-impact skills that top companies want.</li>
                            </ul>
                        </div>
                        <div className=''>
                            <div className=' btn1'>
                                <button className='apply-btn  px-4 py-2 '><span onClick={() => openPopup1()} style={{  cursor: "pointer" }}>
                                    <a className=" "  style={{color: "#ffffff",textDecoration:'none'}}>Get Started</a>
                                </span>
                                    {isPopup1Open ? <Authentication /> : null}</button>
                            </div>
                        </div>
                        <div className='row count'>
                            <div className='col-lg-3 col-md-3 col-sm-4'>
                                <h1 className='counth1'>230+</h1>
                                <p className='countp'>Learners & Counting</p>
                            </div>
                            <div className=' col-lg-3 col-md-3  col-sm-4'>
                                <h1 className='counth1'>83%</h1>
                                <p className='countp'>Success Ratio</p>
                            </div>
                            <div className='col-lg-3 col-md-3 col-sm-4 '>
                                <h1 className='counth1'>4+</h1>
                                <p className='countp'>Courses</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className=" col-lg-6 ani">
                    <div className='html-img'>
                        <img src="../images/htmlpic.png" height={200} alt=''/>
                    </div>
                    <div className='BG-img'>
                        <img src="../images/student-hdr.png" height={100} alt=''/>
                    </div>
                    <div className='arrow-img'>
                        <img src="../images/arrow.png" height={80} alt=''/>
                    </div>
                    <div className='html2-img'>
                        <img src="../images/htmlimg2.png" height={80} alt=''/>
                    </div>
                </div>

            </div>

        </>
    )
}
export default Header

