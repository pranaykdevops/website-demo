import React from 'react';
import '../css/information.css';
import { Link } from 'react-router-dom';


export default function Information() {


  return (
    <div className='row gx-0 justify-content-center information'>
      <div className='contact-info'>
        <div className='d-flex'>
          <div className='col-lg-6 info-contact'>
            <div className=' ps-5 w-100'>
              <h1 className='infoh1'>Get more information</h1>
              <p className='infotext-wrap'>
                For in-depth details, feel free to reach out and request additional information about our program.
              </p>
              <div className=' btn2'>
                <button className='info-btn  px-4 py-2 '><Link to='/contact' style={{ color: "#ffffff" ,textDecoration:'none'}}>Contact Now</Link></button>
              </div>
            </div>
          </div>
          <div className='col-lg-6 info-image '>
            <div>
              <img src='../images/Iluustration.png' alt='' />
            </div>
            <div className='info-curve'>
              <img src="../images/curve.png" height={100} alt=''/>
            </div>
          </div>
        </div>
        <hr className='m-0' />
      </div>
    </div>
  );
}
