import React, { useEffect, useState } from 'react'
import '../css/internship.css'
import Navbar from './Navbar'
import { CalendarEventFill, CurrencyRupee, MortarboardFill } from 'react-bootstrap-icons'
import Enroll from './Forms/Enroll';
import { Link } from 'react-router-dom';
import { Footer } from './Footer';
import axios from 'axios';
import apiUrl from '../config';


export default function Internship() {
    const [intershipBatch, setInternshipBatch] = useState([])

    const getAllInternshipBatches = async () => {
        try {
            const response = await fetch(apiUrl + "/allinternship");
            if (response.ok) {
                const data = await response.json();
                setInternshipBatch(data);

            } else {
                console.log('Error:', response.status);
            }
        } catch (error) {
            console.log(error);
        }
    }

    console.log(intershipBatch, "dskjfbgjdskh")
    const today = new Date()
    const day = String(today.getDate()).padStart(2, '0');
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const year = today.getFullYear();
    const todayDate = `${year}yyyy-${month}mm-${day}dd`;

    function filterdArray() {
        const remainingBatches = intershipBatch.filter((val) => {
            const givenDate = new Date(val.batch)
            const givenday = String(givenDate.getDate()).padStart(2, '0');
            const givenmonth = String(givenDate.getMonth() + 1).padStart(2, '0');
            const givenyear = givenDate.getFullYear();
            const givenDateformate = `${givenyear}yyyy-${givenmonth}mm-${givenday}dd`;
            if (todayDate >= givenDateformate) {
                let index = intershipBatch.indexOf(val)
                intershipBatch.splice(index, 1)
            }
        });

        const remainingBatchIds = remainingBatches.map(batch => batch.id);
        return remainingBatchIds;
    }
    const remainingBatchIds = filterdArray()
    useEffect(() => {
        getAllInternshipBatches()
    }, [])

    return (
        <>
            <div className='sticky-top'>
                <Navbar />
            </div>
            <div className='internship-container ' id='internship'>
                {/* <div className='internship-dropdown'>
                        <div className="dropdown">
                            <a className=" intern-dropdown dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                                Select Course
                            </a>
                            <ul className="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <li><a className="dropdown-item" href="#">  Data Science</a></li>
                                <li><a className="dropdown-item" href="#">Mern stack</a></li>
                            </ul>
                        </div>
                </div> */}
                <div className='image-intern row '>
                    <div className='col-lg-9' >
                        <div className='mt-4'>
                            <span className='image-intern-heading'>  <img src="../images/hands.svg" className='hands-img' alt='' />Guarantee placement for the top 10 interns</span>
                        </div>
                        <h5 className='internship-program'>Internship program & workshop</h5>
                        <div className='internship-course-block'>
                            <h1 className='internship-course-stack'>MERN Stack</h1>
                            <p className='internship-course-content'>React JS was built on the concept of efficiency of performance and fast responses, and it has been very useful in single-page application development, because it is easy to use and completely free.</p>
                        </div>
                        <div className='internship-eligible'>
                            <div className='intership-eligible-year'>
                                <h1 className='eligible-year-date'>2022-2024</h1>
                                <p className='eligiblity'>Eligible Students</p>
                            </div>
                            <div className='intership-mode'>
                                <h1 className='eligible-year-date'>Online</h1>
                                <p className='eligiblity'>Mode</p>
                            </div>

                            <div className='intership-graduation '>
                                <p className='internship-any-graduation'>Any Graduate</p>
                            </div>
                        </div>

                        <div >
                            {
                                intershipBatch.map((data) => {
                                    return (
                                        <div className='internship-free'>
                                            <div className='internship-block'>
                                                <div className='internship-frees'>
                                                    <div className='internship-free-1'>
                                                        <span><MortarboardFill size={20} className='chech2circle  ' /></span>
                                                    </div>
                                                    <div className='internship-frees'>

                                                        <div className='intern-course'>
                                                            <p className='Course-Duration'> Batch Starts</p>
                                                            <p className='Course-months'> {data.batch}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className='internship-frees'>
                                                    <div className='internship-free-1'>
                                                        <span><CalendarEventFill size={20} className='chech2circle  ' /></span>
                                                    </div>
                                                    <div className='intern-course'>
                                                        <p className='Course-Duration'>Next Batch</p>
                                                        <p className='Course-months'> {data.batch}</p>
                                                    </div>
                                                </div>
                                                <div className='internship-frees '>
                                                    <div className='internship-free-1'>
                                                        <span><CurrencyRupee size={20} className='chech2circle  ' /></span>
                                                    </div>
                                                    <div className='intern-course'>
                                                        <p className='Course-Duration'>Program Fee</p>
                                                        <p className='Course-months'>{data.fee}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    )
                                })
                            }
                        </div>

                    </div>
                    <div className='col-lg-3 mb-4'>
                        <Enroll batch={intershipBatch} />
                    </div>
                </div>
            </div>
            <div className='internship-beginner'>
                <div className='internship-beginner-block'>
                    <h3 className='beginner-heading'>Go from beginner to pro in <span className='months'>3 months</span></h3>
                    <p className='beginner-p'>Unlock your potential and transform into a tech pro in just three months, with hands-on training and personalized mentorship from industry experts. Elevate your career with guaranteed success.</p>
                </div>
            </div>
            <div className='benefits-main '>
                <h5 className='benefits-head mb-5'>Internship Benefits</h5>
                <div className='internship-benefits row gx-0 '>
                    <div className='internship-benefits-1 col-lg-6 col-md-6 col-sm-12'>
                        <img src="../images/internship-icon1.svg" className='benefits-icon' alt='' />
                        <h5 className='benefits-name'>Enhanced Learning</h5>
                        <p className='benefits-p'>Daily 2-hour online classNamees and real-time case studies provide a structured learning environment, helping you gain in-depth knowledge and practical skills in your chosen field.</p>
                    </div>
                    <div className='internship-benefits-2 col-lg-6 col-md-6 col-sm-12'>
                        <img src="../images/internship-icon2.svg" className='benefits-icon' alt='' />
                        <h5 className='benefits-name1'>Flexibility and Convenience</h5>
                        <p className='benefits-p1'>Online classNamees and mentoring sessions offer flexibility, allowing you to balance your learning with other commitments and providing a convenient way to acquire valuable skills without the need for physical attendance.</p>
                    </div>
                </div>
                <hr className='benefits-hr' />
                <hr className='benefits-hr2' />
                <div className='internship-benefits'>
                    <div className='internship-benefits row gx-0'>
                        <div className='internship-benefits-1 col-lg-6 col-md-6 col-sm-12'>
                            <img src="../images/internship-icon3.svg" className='benefits-icon' alt='' />
                            <h5 className='benefits-name'>Skill Validation</h5>
                            <p className='benefits-p'>Upon completion of the program, the course completion certificate serves as tangible evidence of your newly acquired skills and knowledge, making you more marketable to potential employers.</p>
                        </div>
                        <div className='internship-benefits-2'>
                            <img src="../images/internship-icon4.svg" className='benefits-icon' alt='' />
                            <h5 className='benefits-name1'>Personalized Guidance</h5>
                            <p className='benefits-p1'>1:1 daily mentoring allows you to receive individualized feedback and support, facilitating a deeper understanding of the subject matter and helping you overcome challenges more effectively.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div className='internship-projects '>
                <div className='project-block'>
                    <div className='projects row '>
                        <div className='col-lg-6' >
                            <h5 className='projects-head'>Projects Include</h5>
                            <p className='project-content'>As a MERN stack intern, you may complete various web development projects, such as building e-commerce websites, social media platforms, real-time chat applications, or task management systems, depending on the organization's requirements and goals.</p>
                            <img className='project-1' src="../images/internship-project1.png" width={'100%'} alt='' />
                        </div>
                        <div className=' col-lg-6 '>
                            <img src="../images/internship-project2.png" width={'100%'} alt='' />
                        </div>
                    </div>
                    <div className=' project-imgs row'>
                        <img src="../images/internship-project3.png" className='col-lg-4' alt='' />
                        <img src="../images/internship-project4.png" className='col-lg-4' alt='' />
                        <img src="../images/internship-project5.png" className='col-lg-4' alt='' />
                    </div>
                </div>
            </div>
            <div className='placement-block '>
                <div className='placement-header-block' >
                    <h5 className='placement-heading'>How will you get guaranteed placement?</h5>
                    <p className='placement-head-content'>While we can provide training to enhance your job-seeking skills, it's important to note that securing a job ultimately depends on various factors, including your efforts, qualifications, and the job market.</p>
                </div>
                <div className='placement-body row gx-0'>
                    <div className='become-placement col-lg-6 col-md-6 col-sm-12'>
                        <img src="../images/internship-placement1.png" width={'100%'} alt='' />
                        <div className='internship-placement-ready-head'>
                            <span className='placement-ready-head'>Become placement-ready</span>
                        </div>
                        {/* <span className='placement-ready-head'>Become placement-ready</span> */}
                        <p className='placement-ready-content'>Our experienced career coaches, with over 10 years of knowledge, will help you prepare for placements, eliminating job search worries.</p>
                        <div className='placement-icon'>
                            <img src="../images/soft-skils.svg" className='placement-icon-img' alt='' />
                            <p className='placement-icon-content'>Soft Skills</p>
                        </div>
                        <hr className='hr' />
                        <div className='placement-icon'>
                            <img src="../images/mock-interview.svg" className='placement-icon-img' alt='' />
                            <p className='placement-icon-content'>Mock Interview Practice</p>
                        </div>
                    </div>
                    <div className='become-placement col-lg-6 col-md-6 col-sm-12'>
                        <img src="../images/internship-placement2.png" width={'100%'} alt='' />
                        <div className='internship-placement-guaranted'>
                        <span className='placement-guaranted'>Get guaranteed placement</span>
                        </div>
                        
                        <p className='placement-ready-content'>Open doors to a brighter future and embark on your path to success with our promise of a secure career through guaranteed placement.</p>
                        <div className='placement-icon'>
                            <img src="../images/interview.svg" className='placement-icon-img' alt='' />
                            <p className='placement-icon-content'>Placement Oppurtunity</p>
                        </div>
                        <hr className='hr' />
                        <div className='placement-icon'>

                            <img src="../images/placement.svg" className='placement-icon-img' alt='' />
                            <p className='placement-icon-content'>Direct Interviews</p>
                        </div>
                    </div>
                </div>
            </div>
            <div className='counseller'>
                <div className='counseller-block'>
                    <p className='counseller-content'>Have doubts about Full Stack Development Placement Guarantee Course? Reach out to our counsellors by filling this form.</p>
                    <Link to='/contact'><button className='counseller-btn'>Speak to Counseller</button></Link>
                </div>
            </div>

            <div>
                <Footer />
            </div>

        </>
    )
}
