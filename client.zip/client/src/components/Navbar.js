import React from 'react'
import { Link } from 'react-router-dom'
import '../css/header.css'
import Authentication from './Forms/Authentication';
import { PopupContext } from '../PopupProvider';
import AuthenticationSuccess from './Forms/AuthenticationSuccess';
import {useNavigate} from 'react-router-dom'

const Navbar = () => {

    const { isPopup1Open, openPopup1, isPopup2Open } = React.useContext(PopupContext);
    const userLoggedIn = localStorage.getItem("userId")
    const navigate = useNavigate()

  

    const myDashboard = () => {
        navigate('/StudentDashboard')
    }

    return (
        <div>
            <div className='container-fluid navbar sticky-top w-100 p-0'>
                <nav className="navbar navbar-expand-lg bg-body-tertiary w-100 p-2 ">
                    <div className="container-fluid ms-5  ">
                        <div>
                            <img src="../images/Logo.png" width={150} alt='' />
                        </div>
                        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>
                        <div className="collapse navbar-collapse " id="navbarNavDropdown">
                            <div className='navbar-nav1  ms-auto  me-0'>
                            <ul className="navbar-nav ms-auto" >
                                <li className="nav-item">
                                    <Link
                                        className='home-link anchor-link home'
                                        to='/'

                                    >
                                        Home
                                    </Link>

                                </li>
                                <li className="nav-item dropdown">
                                    <a className='anchor-link dropdown-toggle '  role="button" data-bs-toggle="dropdown" aria-expanded="false"
                                    >
                                        Courses
                                    </a>
                                    <ul className="dropdown-menu">
                                        <li><Link className="dropdown-item" style={{ color: '#000' }} to='/mernstack'>Mern Stack</Link></li>
                                        <li><Link className="dropdown-item" style={{ color: '#000' }} to='/meanstack'>Mean Stack</Link></li>
                                        <li><Link className="dropdown-item" style={{ color: '#000' }} to='/datascience'>Data Science</Link> </li>
                                        <li><Link className="dropdown-item" style={{ color: '#000' }} to='/devops'>DevOps</Link> </li>
                                    </ul>
                                </li>

                                <li className="nav-item">
                                    <Link
                                        className=' anchor-link'
                                        to='/internship'

                                    >
                                        Internship
                                    </Link>
                                </li>
                            </ul>
                            </div>
                             <div className='ms-2'>
                                {userLoggedIn ? (
                                   <button className='dashboard-button'> <span className='dashboard-text' onClick={myDashboard} >
                                        Dashboard
                                    </span></button>
                                ) : (
                                    <span onClick={() => openPopup1()} style={{ color: "#C67A97", cursor: "pointer" }}>
                                        <a className="register-link registeration-link" >
                                            Register/Login
                                        </a>
                                    </span>
                                )}
                                {isPopup1Open ? <Authentication /> : null}
                                {isPopup2Open && <AuthenticationSuccess />}
                            </div>
                          
                        </div>

                    </div>
                </nav>
            </div>
        </div>
    )
}

export default Navbar