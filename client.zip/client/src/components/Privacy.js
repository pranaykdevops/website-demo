import React from 'react'
import Navbar from './Navbar'
import '../css/term-Privacy.css'
import { Footer } from './Footer'
export default function Privacy() {
    return (
        <>
            <div>
                <div className='sticky-top'>
                    <Navbar />

                </div>
                <div className='terms-container' >
                    <div className=' '>
                        <h5 className='terms-head' style={{ fontSize: "30px", textAlign: 'center' }}>PRIVACY POLICY</h5>
                        <p className='terms-content'>
                            TechU by Abilio IT Solutions is committed to protecting the privacy and security of your personal information. This Privacy Policy outlines how we collect, use, disclose, and protect the information you provide to us through our website, www.techu.in. By accessing or using our website, you consent to the collection and use of your information as described in this Privacy Policy.
                        </p>
                    </div>
                    <div>
                        <h5 className="terms-head">Information We Collect: </h5>
                        <p className='terms-content'>We may collect personal information that you provide to us voluntarily, such as your name, email address, phone number, and resume when you apply for job placements or use our IT services. The personal information that you are asked to provide, and the reasons why you are asked to provide it, will be made clear to you at the point we ask you to provide your personal information.
                            Additionally, we may collect non-personal information such as IP addresses, browser type, and operating system information.
                        </p>
                    </div>
                    <div>
                        <h5 className="terms-head" >Use of Information: </h5>
                        <p className='terms-content'>We may use the collected information for the following purposes:</p>
                        <ul className='terms-content'>
                            <li>Providing our services, including job placement and IT services.</li>
                            <li>Responding to inquiries and providing customer support.</li>
                            <li>Communicate with you, either directly or through one of our partners.</li>
                            <li>Sending you important notifications and updates about our services.</li>
                            <li>Personalizing your experience on our website.</li>
                            <li>Analyzing and improving our services and the website's functionality.</li>
                            <li>Complying with legal obligations and preventing fraud.</li>
                        </ul>
                    </div>
                    <div>
                        <h5 className="terms-head">Sharing of Information: </h5>
                        <p className='terms-content'>We may share your personal information with third parties under the following circumstances:</p>
                        <ul className='terms-content'>
                            <li>With your consent or as necessary to fulfill your requests.</li>
                            <li>With our trusted service providers who assist us in operating our business and providing services to you.</li>
                            <li>With prospective employers when you apply for job placements through our website.</li>
                            <li>Sending you important notifications and updates about our services.</li>
                            <li>To comply with applicable laws, regulations, or legal processes, or to respond to valid governmental requests.</li>
                            <li>To protect our rights, property, or safety, or the rights, property, or safety of our users or others.</li>

                        </ul>
                    </div>
                    <div>
                        <h5 className="terms-head">Cookies and Web Beacons:</h5>
                        <p className='terms-content'>Like any other website, www.techu.com may use "cookies". These cookies are used to store information including visitors' preferences, and the pages on the website that the visitor accessed or visited. The information is used to optimize the users' experience by customizing our web page content based on visitors browser type and/or other information.</p>
                    </div>
                    <div>
                        <h5 className="terms-head">Data Retention: </h5>
                        <p className='terms-content'>We will retain your personal information only for as long as necessary to fulfill the purposes outlined in this Privacy Policy unless a longer retention period is required or permitted by law.</p>
                    </div>
                    <div>
                        <h5 className="terms-head">Security Measures:</h5>
                        <p className='terms-content'>We employ reasonable security measures to protect the information we collect from unauthorized access, disclosure, alteration, or destruction. However, no method of transmission over the Internet or electronic storage is 100% secure, and we cannot guarantee absolute security.</p>
                    </div>
                    <div>
                        <h5 className="terms-head">Third-Party Links:</h5>
                        <p className='terms-content'>Our website may contain links to third-party websites or services that are not owned or controlled by us. We are not responsible for the privacy practices or content of such websites or services. We encourage you to review the privacy policies of those third parties before providing any personal information.</p>
                    </div>
                    <div>
                        <h5 className="terms-head">Children's Privacy: </h5>
                        <p className='terms-content'>Our website is not intended for children under the age of 13. We do not knowingly collect personal information from children under the age of 13. If we become aware that we have collected personal information from a child under the age of 13, we will take steps to delete such information.</p>
                    </div>
                    <div>
                        <h5 className="terms-head">Changes to the Privacy Policy: </h5>
                        <p className='terms-content'>We reserve the right to modify or update this Privacy Policy at any time without prior notice. Any changes will be effective immediately upon posting the revised Privacy Policy on our website. We encourage you to review this Privacy Policy periodically.</p>
                    </div>
                    <div>
                        <h5 className="terms-head">Contact Information: </h5>
                        <p className='terms-content'>If you have any questions or concerns regarding this Privacy Policy, please contact us at <strong> <a href='#' style={{ textDecoration: "none", color: "#C76A97", fontSize: "20px" }}>info@techu.com</a></strong> or <b style={{ color: "#C76A97" }}>040-40261333</b>.
                        </p>
                    </div>
                </div>
                <div>
                    <Footer />
                </div>
            </div>
        </>
    )
}
