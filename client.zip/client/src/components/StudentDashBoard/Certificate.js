import React from 'react'

export default function Certificate() {
  return (
    <div>
     
      <div style={{}}>
      <img className=" " src="../images/cert.svg" width={"100%"} alt='' />
      </div>
    </div>
  )
}
