import React, { useState, useEffect } from 'react';
import axios from 'axios';
import apiUrl from '../../config';
import ReactPlayer from 'react-player';
import { ArrowLeftShort } from 'react-bootstrap-icons';
import '../../css/courseVideo.css';
import MyCourse from './MyCourse';

const CourseVideos = () => {
  const [videos, setVideos] = useState([]);
  const [show, setShow] = useState(false)
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [searchVideo, setSearchVideo] = useState("");
  const [activeVideoIndex, setActiveVideoIndex] = useState(0);
  const onClose = () => {
    setShow(true)
  };
  const onVideoContentClick = (video, index) => {
    setSelectedVideo(video);
    setActiveVideoIndex(index);
  };
  const BatchId = localStorage.getItem("GetBatchId");

  const getUserVideos = async () => {
    try {
        const response = await fetch(apiUrl + `/batchvideo/${BatchId}`);
        if (response.ok) {
            const data = await response.json();
            const videoList = data?.existingVideo.videosid;
            setVideos(videoList);
            if (videoList.length > 0) {
                setSelectedVideo(videoList[0]);
            }
        } else {
            console.error(`HTTP Error: ${response.status}`);
        }
    } catch (error) {
        console.error(error);
    }
};

console.log(videos,"videos")
  useEffect(() => {
    getUserVideos();
  }, []);

  const filteredVideos = videos.filter((video) => {
    const search = searchVideo.toLowerCase();
    return video.filetitle.toLowerCase().includes(search) || video.videostittle.toLowerCase().includes(search);
  });
  return (
    <div>
      {
        show ? <MyCourse /> : <div>
          <div className="coursevideo-container">
            <div className="courseviedo-head">
              <button className="coursevideo-arrow-button" onClick={onClose}>
                <ArrowLeftShort className="coursevideo-Arrow-icon" size={20} />
              </button>
            </div>
          </div>
          <div className="course-content-dropdown row  justify-content-around">
            <div className='col-lg-4 px-3'>
              <div className="video-list ">
                <input
                className='form-control'
                  type='search'
                  placeholder='Search'
                  onChange={(e) => setSearchVideo(e.target.value)}
                  value={searchVideo}
                />
                {filteredVideos?.map((val, index) => {
                  return (
                    <div
                      className={`video-item ${activeVideoIndex === index ? 'active-video-item' : ''}`}
                      key={index}
                      onClick={() => onVideoContentClick(val, index)}
                    >
                      <button className={`video-item-name ${activeVideoIndex === index ? 'active-video-item' : ''}`}>{val.filetitle} - {val.videostittle}</button>
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="video-container col-lg-8 ">
              {selectedVideo && (
                <div>
                  <h5 className="video-class-title">{selectedVideo.videostittle}</h5>
                  <div className="course-Content-video-play">
                    <ReactPlayer
                      url={selectedVideo.videos}
                      controls={true}
                      pip={true}
                      className="player"
                      width="100%"
                      onContextMenu={(e) => e.preventDefault()}
                      config={{
                        youtube: {
                          playerVars: {
                            modestbranding: 1,
                            fs: 0,
                          },
                        },
                      }}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      }


    </div>
  );
};

export default CourseVideos;
