import React, { useContext, useEffect, useState } from 'react';
import apiUrl from '../../config';
import axios from 'axios';
import '../../css/myCourse.css'
import CourseVideos from './CourseVideos';

export default function MyCourse() {
  const [userData, setUserData] = useState([]);
  const [show, setShow] = useState(false)
  const [paymentMessage, setPaymentMessage] = useState('');
  let userid = localStorage.getItem("userId");
  const getUserData = async () => {
    try {
        const response = await fetch(apiUrl + `/myEnroll/${userid}`);
        if (response.ok) {
            const data = await response.json();
            setUserData(data.user.enrolls);
        } else {
            console.error(`HTTP Error: ${response.status}`);
        }
    } catch (error) {
        console.error(error);
    }
};

  // const getBatchId = async () => {
  //   try {
  //     const response = await axios.get(apiUrl + `/myEnroll/${userid}`);
  //     const batchId = userData[0]?.batches[0];
  //     localStorage.setItem("GetBatchId", batchId)
  //     return batchId;
  //   } catch (error) {
  //     console.error(error);
  //     return null;
  //   }
  // }

  const onNextPage = async () => {
    try {
      const batchId = userData[0]?.batches[0];
      localStorage.setItem("GetBatchId", batchId)
      if (batchId && userData.some(val => val.payment === true)) {
        setShow(true)

      } else {
        setPaymentMessage("Please confirm that the payment has been completed.");
      }
    } catch (error) {
      console.error("Error during navigation:", error);
    }
  }

  const Image = () => {
    let courseData = userData[0]?.course
    if (courseData === 'Data Science') {
      return <img src='../images/data-science.png' alt="Data Science" className='myCourse-img' />;
    } else if (courseData === 'Mean Stack') {
      return <img src='../images/mean.png' alt="Mean Stack" className='myCourse-img' />;
    } else if (courseData === 'Devops') {
      return <img src='../../../images/MicrosoftTeams-image.png' alt="Devops" className='myCourse-img' />;
    } else {
      return <img src='../../../images/mern.png' alt="Mern Stack" className='myCourse-img' />;
    }
  }

  useEffect(() => {
    getUserData();
  }, []);

  return (
    <>
      <div>
        {show ? <CourseVideos /> : (
          <div>
            <div className='mycourse-container'>
              <div className='mycourse-head'>
                <h4 className='mycourses-name'>My Course</h4>
              </div>
              <div className='mycourse-card-main' onClick={onNextPage}>
                <div className="mycourse-card" >
                  <div style={{ width: '18rem' }}>
                    {userData[0]?.course && <Image />}
                    <div className="mycourse-card-body">
                      {
                        userData.map((val, index) => (
                          <div key={index}>
                            <h1 className='mycourse-course-name mt-4'>{val.course}</h1>
                          </div>
                        ))
                      }
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      <div className='paymentMassage' style={{ width: '18rem' }}>
        {paymentMessage}
      </div>
    </>
  )
}
