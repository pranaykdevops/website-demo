import React, { useEffect, useState } from 'react'
import axios from 'axios'
import apiUrl from '../../config'


export default function Notifications() {
  const [getMessage, setGetMessage] = useState([])
  const BatchId = localStorage.getItem("GetBatchId");

  const Message = async () => {
    try {
        const response = await fetch(apiUrl + `/getMessage/${BatchId}`);
        if (response.ok) {
            const data = await response.json();
            setGetMessage(data.existingnotification.notificationId);
        } else {
            console.log(`HTTP Error: ${response.status}`);
        }
    } catch (err) {
        console.log(err);
    }
}

  const formatTime = (timeString) => {
    const options = { hour: 'numeric', minute: 'numeric', timeZone: 'Asia/Kolkata' };
    return new Date(timeString).toLocaleTimeString(undefined, options);
  }

  const formatDateTime = (dateTimeString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', timeZone: 'Asia/Kolkata' };
    return new Date(dateTimeString).toLocaleString(undefined, options);
  }
  useEffect(() => {
    Message()
  }, [])

  return (
    <div>
      {getMessage.map((item, index) => {
        const itemDate = new Date(item.createdAt);
        const today = new Date();
        const isToday = itemDate.getDate() === today.getDate() &&
          itemDate.getMonth() === today.getMonth() &&
          itemDate.getFullYear() === today.getFullYear();
        return (
          <div className='notifiaction-contant' style={{ width: "30rem" }} key={index}>
            <div className='notifiaction-delete-btn'>
              <h6 >{item.message}</h6>
            </div>
            <span style={{ paddingLeft: '200px' }}>   {isToday ? 'Today' : formatDateTime(item.createdAt)}  {isToday && formatTime(item.createdAt)}</span>
          </div>
        )
      })
      }
    </div>
  )
}
