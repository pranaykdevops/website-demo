import React, { useEffect, useState } from 'react';
import { ArrowLeftShort, PersonCircle } from 'react-bootstrap-icons';
import '../../css/profile.css';
import axios from 'axios';
import apiUrl from '../../config';

export default function Profile() {
  const [userdetails, setUserdetails] = useState({});
  const [editMode, setEditMode] = useState(false);
  const [userProfile, setUserProfile] = useState({})
  const userId = localStorage.getItem('userId');
  const email = userdetails?.email;
  const phonenumber = userdetails?.phonenumber;
  const fullName = userdetails?.name;
  const nameParts = fullName?.split(" ");
  const firstName = (nameParts) ? nameParts[0] : "";
  const lastName = (nameParts) ? nameParts[nameParts.length - 1] : "";
  const [userEducation, setUserEducation] = useState({
    firstName: firstName,
    lastName: lastName,
    email: userdetails?.email,
    phoneNumber: userdetails?.phonenumber,
    houseNumber: '',
    streetName: '',
    locality: '',
    district: '',
    city: '',
    state: '',
    pincode: '',
    instituteName: '',
    passedOutYear: '',
    branch: '',
    linkedin: '',
    github: '',
    registerId: userId
  });


  const getUserDetails = async () => {
    try {
        const response = await fetch(apiUrl + `/user/UserDetails/${userId}`);
        if (response.ok) {
            const data = await response.json();
            setUserdetails(data);
        } else {
            console.log(`HTTP Error: ${response.status}`);
        }
    } catch (err) {
        console.log(err);
    }
}

const getProfileDetails = async () => {
    try {
        const response = await fetch(apiUrl + `/myProfile/${userId}`);
        if (response.ok) {
            const data = await response.json();
            setUserProfile(data.existingProfile.profileId);
        } else {
            console.log(`HTTP Error: ${response.status}`);
        }
    } catch (err) {
        console.log(err);
    }
}

const onSubmitForm = async () => {
    try {
        if (userId === userProfile[0]?.registerId[0]) {
            const response = await fetch(apiUrl + `/updateProfile/${userProfile[0]?._id}`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(userEducation),
            });

            if (response.ok) {
                const data = await response.json();
                if (data && data.AllProfile) {
                    setUserEducation(data.AllProfile);
                }
            }
        } else {
            const response = await fetch(apiUrl + '/addProfile', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(userEducation),
            });

            if (response.ok) {
                const data = await response.json();
                setUserEducation(data.profile);
            }
        }
        setEditMode(true);
    } catch (e) {
        console.log(e);
    }
}

  const onChangeSubmit = (e) => {
    const { name, value } = e.target;
    setUserEducation((prevData) => ({ ...prevData, [name]: value }));
  };
  const onEducationSubmit = (e) => {
    e.preventDefault();
  };

  const onOpen = () => {
    setEditMode(!editMode);
  };
  // setUserEducation(prevData => ({
  //   ...prevData,
  //   email: userdetails.email,
  //   phoneNumber: userdetails.phonenumber,
  //   firstName: (nameParts) ? nameParts[0] : "",
  //   lastName: (nameParts) ? nameParts[nameParts.length - 1] : ""
  // }));
  useEffect(() => {
    getUserDetails()
    getProfileDetails()

  }, [])

  return (
    <>
      {/* {userdetails.map((val) => {
        const email = val.email;
        const phonenumber = val.phonenumber;
        const fullName = val.name;
        const nameParts = fullName.split(" ");
        const firstName = nameParts[0];
        const lastName = nameParts[nameParts.length - 1]; */}

      <div >
        <div className="profile-container">
          <div className="profile-head">
            {/* <button className="profile-head-button">
                  <ArrowLeftShort className="profile-arrow" size={20} />
                </button> */}
            <h4 className="profile-name">Profile</h4>
          </div>
          <div className="profile-view">
            <PersonCircle className="profile-icon-profile" size={100} />
            <h6 className="profile-view-name">{firstName}</h6>
            <div className="d-flex">
              <h6 className="profile-view-id">Email-</h6>
              <h6 className="profile-view-id">{email}</h6>
            </div>
          </div>
          <div className="personal-information">
            <div className="personal-head">
              <button className="personal-information-button" onClick={onOpen}>
                {editMode ? "Cancel" : "Edit"}
              </button>
            </div>
            {editMode ? (

              <form onSubmit={onEducationSubmit}>
                <div className='user-personal-details'>
                  <p className="personal-head-name">Personal Information</p>
                  <div className="personal-names ">
                    <div className="personal-information-name-edit">
                      <label className="personal-firstname">First Name</label>
                      <input type="text"
                        className="input-values form-control"
                        name="firstName"
                        value={firstName} readOnly />
                    </div>
                    <div className='personal-information-name-edit'>
                      <label className='personal-firstname'>Last Name</label>
                      <input
                        className="input-values form-control"
                        type='text'
                        name='lastName'
                        value={lastName}
                        onChange={onChangeSubmit}
                      />
                    </div>
                  </div>
                  <div className='personal-names'>
                    <div className='personal-information-name-edit'>
                      <label className='personal-firstname'>Email</label>
                      <input
                        className="input-values form-control"
                        type='text'
                        name='Email'
                        value={email}
                        onChange={onChangeSubmit}
                      />
                    </div>
                    <div className='personal-information-name-edit'>
                      <label className='personal-firstname'>Phone Number</label>
                      <input
                        className="input-values form-control"
                        type='text'
                        name='phonenumber'
                        value={phonenumber}
                        onChange={onChangeSubmit}
                      />
                    </div>
                  </div>
                  {/* <div className="information-bio">
                    <h6 className="information-bio-name">Bio</h6>

                    <input
                      type='text'
                      name='pincode'
                      value={userEducation?.bio}
                      onChange={onChangeSubmit}
                      id='bio'
                      className='form-control'
                    />
                  </div> */}
                </div>
                <div className='address'>
                  <p className="personal-head-name">Address</p>
                  <form className="mt-4" onSubmit={onEducationSubmit}>
                    <div className='address-items'>
                      <div className='form-group'>
                        <label className='personal-firstname' htmlFor='homeNo'>House Number</label>
                        <input
                          type='text'
                          name='houseNumber'
                          value={userEducation?.houseNumber}
                          onChange={onChangeSubmit}
                          id='homeNo'
                          className='input-values form-control'
                        />
                      </div>
                      <div className='form-group'>
                        <label className='personal-firstname' htmlFor='streetName'>Street Name</label>
                        <input
                          type='text'
                          name='streetName'
                          value={userEducation?.streetName}
                          onChange={onChangeSubmit}
                          id='streetName'
                          className='input-values form-control'
                        />
                      </div>
                      <div className='form-group'>
                        <label className='personal-firstname' htmlFor='locality'>Locality</label>
                        <input
                          type='text'
                          name='locality'
                          value={userEducation?.locality}
                          onChange={onChangeSubmit}
                          id='locality'
                          className='form-control'
                        />
                      </div>
                      <div className='form-group'>
                        <label className='personal-firstname' htmlFor='district'>District</label>
                        <input
                          type='text'
                          name='district'
                          value={userEducation?.district}
                          onChange={onChangeSubmit}
                          id='district'
                          className='input-values form-control'
                        />
                      </div>
                    </div>
                    <div className='address-items-edit '>
                      <div className='form-group'>
                        <label className='personal-firstname' htmlFor='city'>City Name</label>
                        <input
                          type='text'
                          name='city'
                          value={userEducation?.city}
                          onChange={onChangeSubmit}
                          id='city'
                          className='input-values form-control'
                        />
                      </div>
                      <div className='form-group'>
                        <label className='personal-firstname ' htmlFor='state'>State</label>
                        <input
                          type='text'
                          name='state'
                          value={userEducation?.state}
                          onChange={onChangeSubmit}
                          id='state'
                          className='input-values form-control'
                        />
                      </div>
                      <div className='form-group'>
                        <label className='personal-firstname ' htmlFor='pincode'>Pincode</label>
                        <input
                          type='text'
                          name='pincode'
                          value={userEducation?.pincode}
                          onChange={onChangeSubmit}
                          id='pincode'
                          className='input-values form-control'
                        />
                      </div>
                    </div>
                  </form>
                </div>
                <div className="education">
                  <p className="personal-head-name">Education</p>

                  <form className="mt-4 " onSubmit={onEducationSubmit}>
                    <div className='eduction-qualification'>
                      <div className="form-outline ">
                        <label className='personal-firstname' htmlFor="form4Example1">Institute Name</label>
                        <input type="text" id="form4Example1" name="instituteName" onChange={onChangeSubmit} className="form-control" value={userEducation?.instituteName} />
                      </div>
                      <div className="form-outline ">
                        <label className='personal-firstname' htmlFor="form4Example2">Passed Out Year</label>
                        <input type="date" id="form4Example2" name="passedOutYear" onChange={onChangeSubmit} className="form-control" value={userEducation?.passedOutYear} />
                      </div>
                      <div className="form-outline">
                        <label className='personal-firstname mb-2' htmlFor="form4Example2">Branch</label>
                        <input type="text" id="form4Example2" name="branch" onChange={onChangeSubmit} className="form-control" value={userEducation?.branch} />
                      </div>
                    </div>
                  </form>

                </div>
                <div className='links'>
                  <div className='links-head-name'>
                    <p className='personal-head-name'>links</p>
                    <div className='links-items'>
                      <form onSubmit={onEducationSubmit}>
                        <div className='mt-2'>
                          <label className='personal-firstname'>Linkedin</label>
                          <input type='text' className='form-control' name='linkedin' value={userEducation.linkedin} onChange={onChangeSubmit} />
                        </div>
                        <div className='mt-2'>
                          <label className='personal-firstname'>Github</label>
                          <input type='text' className='form-control' name='github' value={userEducation.github} onChange={onChangeSubmit} />
                        </div>
                      </form>
                    </div>

                  </div>
                </div>
                <div className='information-submit-button'>
                  <button type="submit" onClick={onSubmitForm} className="btn-submit-button">submit</button>
                </div>
              </form>
            ) : (
              <div>
                <div className='user-personal-details'>
                  <div className='profile-personal-head-names'>
                    <p className="personal-head-name">Personal Information</p>
                    <div className="personal-names mt-4">
                      <div className="personal-information-name">
                        <label className="personal-firstname">First Name</label>
                        <h1 className='student-information-details'>{firstName}</h1>
                      </div>
                      <div className='personal-lastname'>
                        <label className='personal-firstname'>Last Name</label>
                        <h1 className='student-information-details'>{lastName}</h1>
                      </div>
                    </div>
                    <div className='personal-names'>
                      <div className='personal-information-name'>
                        <label className='personal-firstname'>Email</label>
                        <h1 className='student-information-details'>{email}</h1>
                      </div>
                      <div>
                        <label className='personal-firstname'>Phone Number</label>
                        <h1 className='student-information-details'>{phonenumber}</h1>
                      </div>
                    </div>
                    {/* <div className="information-bio">
                      <h6 className="information-bio-name">Bio</h6>
                      <p className="information-bio-text">{userEducation?.bio}</p>
                    </div> */}
                  </div>
                </div>
                <div className='address'>
                  <p className="personal-head-name">Address</p>
                  <form className="mt-4" onSubmit={onEducationSubmit}>
                    <div className='address-items'>
                      <div className='form-group'>
                        <label className='personal-firstname' htmlFor='homeNo'>House Number</label>
                        <h1 className='student-information-details'>{userProfile[0]?.houseNumber}</h1>
                      </div>
                      <div className='form-group'>
                        <label className='personal-firstname' htmlFor='streetName'>Street Name</label>
                        <h1 className='student-information-details'>{userProfile[0]?.streetName}</h1>
                      </div>
                      <div className='form-group'>
                        <label className='personal-firstname' htmlFor='locality'>Locality</label>
                        <h1 className='student-information-details'>{userProfile[0]?.locality}</h1>
                      </div>
                      <div className='form-group'>
                        <label className='personal-firstname' htmlFor='district'>District</label>
                        <h1 className='student-information-details'>{userProfile[0]?.district}</h1>
                      </div>
                    </div>
                    <div className='address-items-2'>
                      <div className='form-group'>
                        <label className='personal-firstname' htmlFor='city'>City Name</label>
                        <h1 className='student-information-details'>{userProfile[0]?.city}</h1>
                      </div>
                      <div className='form-group'>
                        <label className='personal-firstname' htmlFor='state'>State</label>
                        <h1 className='student-information-details'>{userProfile[0]?.state}</h1>
                      </div>
                      <div className='form-group'>
                        <label className='personal-firstname' htmlFor='pincode'>Pincode</label>
                        <h1 className='student-information-details'>{userProfile[0]?.pincode}</h1>
                      </div>
                    </div>
                  </form>
                </div>
                <div className="education">
                  <p className="personal-head-name">Education</p>
                  <div className='mt-4'>
                    <form className="eduction-qualification" onSubmit={onEducationSubmit}>
                      <div className="form-outline mb-3">
                        <label className="personal-firstname" htmlFor="form4Example1">Institute Name</label>
                        <h1 className='student-information-details'>{userProfile[0]?.instituteName}</h1>
                      </div>
                      <div className="form-outline mb-3">
                        <label className="personal-firstname" htmlFor="form4Example2">Passed Out Year</label>
                        <h1 className='student-information-details'>{userProfile[0]?.passedOutYear}</h1>
                      </div>
                      <div className="form-outline mb-3">
                        <label className="personal-firstname" htmlFor="form4Example2">Branch</label>
                        <h1 className='student-information-details'>{userProfile[0]?.branch}</h1>
                      </div>
                    </form>
                  </div>
                </div>
                <div className='links'>
                  <div className='links-head-name'>
                    <p className='personal-head-name'>links</p>
                    <div className=' mt-4 links-items'>
                      <form onSubmit={onEducationSubmit}>
                        <div className=''>
                          <label className='personal-firstname'>Linkedin</label>
                          <h1 className='student-information-details'>{userProfile[0]?.linkedin}</h1>
                        </div>
                        <div className=''>
                          <label className='personal-firstname'>Github</label>
                          <h1 className='student-information-details'>{userProfile[0]?.github}</h1>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
                {/* <div className='links'>
                  <div className='links-head-name'>
                    <div className='personal-head '>
                      <p className='personal-head-name'>links</p>
                    </div>
                    <div className='links-items'>
                      <form onSubmit={onEducationSubmit}>
                        <div className=''>
                          <label className='personal-firstname'>Linkedin</label>
                          <h1>{userProfile[0]?.linkedin}</h1>
                        </div>
                        <div className=''>
                          <label className='personal-firstname'>Github</label>
                          <h1>{userProfile[0]?.github}</h1>
                        </div>
                      </form>
                    </div>
                  </div>
                </div> */}
              </div>
            )}
            {/* <div className="information-bio">
                  <h6 className="information-bio-name">Bio</h6>
                  <p className="information-bio-text">{userEducation?.bio}</p>
                </div> */}
          </div>
        </div>
      </div>
    </>
  );
}