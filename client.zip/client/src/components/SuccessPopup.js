import React, { useContext } from 'react'
import { PopupContext } from '../PopupProvider';
// import '../css/popup.css'

const SuccessPopup = () => {

    const { closePopup4, successtext } = useContext(PopupContext);


    const handleClosePopup4 = () => {
        closePopup4();
    };


    return (
        <>
            <div className='successpopup succes-popup-container '>
                <div className="card success-pop success-body">
                    <div className='card-img-top about-success-popup'>
                        <img src="../images/check.png" className='abt-success-pop m-1' alt="..." height={60} width={60} />
                    </div>
                    <div className="card-body success-popup-body p-4">
                        <h5 className="card-title">{successtext.title}</h5>
                        <p className="card-text">{successtext.message}</p>
                        <button className="success-popup-button w-100 p-2 " onClick={handleClosePopup4} style={{ border: "none",borderRadius:"10px" }}>Done</button>
                    </div>
                </div>
            </div>
        </>
    )
}

export default SuccessPopup