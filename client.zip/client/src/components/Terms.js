import React from 'react'
import Navbar from './Navbar'
import '../css/term-Privacy.css'
import { Footer } from './Footer'

export default function Terms() {
    return (
        <>
            <div className=''>
                <div className='sticky-top'>
                    <Navbar />
                </div>
                <div className='terms-container'>
                    <div className=''>
                        <h5 className='terms-head'style={{ fontSize: "30px", textAlign:'center'}}>Terms and Conditions</h5>
                        <p className='terms-content'>Please read these Terms and Conditions ("Terms") carefully before using TechU, a Training, Development, and Placement Services website (referred to as "TechU" or the "website"), owned and regulated TECHU by ABILIO IT SOLUTIONS PVT LTD. These Terms outline the rules and regulations governing your use of the website. By accessing or using TechU, you agree to be bound by these Terms. If you do not agree with any part of these Terms, you may not use the website or its Services.</p>
                    </div>
                    <div>
                        <h5 className='terms-head' >Use of Content:</h5>
                        <p className='terms-content'>All content on the TechU website, including text, graphics, images, logos, and trademarks, is the property of TechU by ABILIO IT Solutions or its affiliates and is protected by copyright laws. You may not modify, reproduce, distribute, transmit, display, or sell any content without prior written permission from TechU.
                            You may use the TechU by Abilio IT Solutions website only for information purposes and in accordance with these terms and conditions. You agree not to use the website:
                            In any way that violates any applicable federal, state, local, or international law or regulation
                            To engage in any conduct that restricts or inhibits anyone's use of the website, or which may harm  TechU by Abilio IT Solutions or users of the website, or expose them to liability
                            To transmit, or procure the sending of, any advertising or promotional material, including any “junk mail,” “chain letter,” “spam,” or any other similar solicitation
                            To engage in any other conduct that restricts or inhibits anyone's use of the website, or which, as determined TechU by Abilio IT Solutions, may harm TechU or users of the website or expose them to liability.</p>
                    </div>
                    <div>
                        <h5 className='terms-head' >User Conduct: </h5>
                        <p className='terms-content'>
                            When using the TechU by Abilio IT Solutions website, you agree to comply with all applicable laws and regulations. You shall not engage in any activity that may disrupt or interfere with the proper functioning of our website or infringe upon the rights of others. This includes but is not limited to, uploading or transmitting harmful or malicious content, engaging in unauthorized access or hacking, or engaging in any illegal activity.</p>
                    </div>
                    <div>
                        <h5 className='terms-head' >  Third-Party Links:  </h5>
                        <p className='terms-content'>Our website may contain links to third-party websites or resources.TechU by Abilio IT Solutions is not responsible for the availability, content, or accuracy of these external sites. The inclusion of any link does not imply endorsement by TechU. You acknowledge and agree that TechU shall not be responsible or liable for any damages or losses resulting from your use of these third-party websites.</p>
                    </div>
                    <div>
                        <h5  className='terms-head'>Accuracy, Completeness, and Timeliness of Information:</h5>
                        <p className='terms-content'>We are not responsible if the information made available on the TechU website is not accurate, complete, or current. The material on this site is provided for general information only and should not be relied upon or used as the sole basis for making decisions without consulting primary, more accurate, more complete, or more timely sources of information. Any reliance on the material on this site is at your own risk.</p>
                    </div>
                    <div>
                        <h5 className='terms-head' >Modifications: </h5>
                        <p className='terms-content'>
                            TechU reserves the right to modify or discontinue any part of the website or its services at any time without notice. We may also revise these terms and conditions from time to time. Your continued use of the website after any changes will constitute your acceptance of such changes.</p>
                    </div>
                    <div>
                        <h5 className='terms-head'>Errors, Inaccuracies, and Omissions:</h5>
                        <p className='terms-content'>Occasionally there may be information on our website or in the Service that contains typographical errors, inaccuracies, or omissions that may relate to Services or Technologies descriptions, pricing, promotions, and availability. We reserve the right to correct any errors, inaccuracies, or omissions, and to change or update information if any information in the Service or on any related website is inaccurate at any time without prior notice.

                            We undertake no obligation to update, amend or clarify information in the Service or on any related website, including without limitation, pricing information, except as required by law. No specified update or refresh date applied in the Service or on any related website should be taken to indicate that all information in the Service or on any related website has been modified or updated.
                        </p>
                    </div>
                    <div>
                        <h5 className='terms-head' >Indemnification:</h5>
                        <p className='terms-content'>You agree to indemnify, defend and hold harmless TechU by Abilio IT Solutions and our parent, subsidiaries, affiliates, partners, officers, directors, mentors, trainers, licensors, service providers, interns, and employees, harmless from any claim or demand, including reasonable services’ fees, made by any third party due to or arising out of your breach of these Terms of Service or the documents they incorporate by reference, or your violation of any law or the rights of a third party.</p>
                    </div>
                    <div>
                        <h5 className='terms-head' >Limitation of Liability: </h5>
                        <p className='terms-content'>In no event shall TechU by Abilio IT Solutions or its affiliates be liable for any direct, indirect, incidental, consequential, or punitive damages arising out of or relating to your use of the website or the services provided, even if TechU has been advised of the possibility of such damages.</p>
                    </div>
                    <div>
                        <h5 className='terms-head' >Severability:</h5>
                        <p className='terms-content'>In the event that any provision of these Terms of Service is determined to be unlawful, void, or unenforceable, such provision shall nonetheless be enforceable to the fullest extent permitted by applicable law, and the unenforceable portion shall be deemed to be severed from these Terms of Service, such determination shall not affect the validity and enforceability of any other remaining provisions.</p>
                    </div>
                    <div>
                        <h5 className='terms-head'>Governing Law: </h5>
                        <p className='terms-content'>
                            These terms and conditions shall be governed by and construed in accordance with the laws of the jurisdiction in which TechU by Abilio IT Solution operates. Any legal action or proceeding arising out of or relating to these terms shall be exclusively brought in the courts located in that jurisdiction.
                        </p>
                    </div>
                    <div>
                        <h5 className='terms-head' >License:</h5>
                        <p className='terms-content'>Unless otherwise stated, TechU by Abilio IT Solutions and/or its licensors own the intellectual property rights for all material on www.techu.com. All intellectual property rights are reserved. You may access this from www.techu.in for your own personal use subject to restrictions set in these terms and conditions.</p>
                    </div>
                    <div>
                        <h5 className='terms-head' >Disclaimer of Warranties:</h5>
                        <p className='terms-content'>
                            We do not guarantee, represent or warrant that your use of our service or technology will be uninterrupted, timely, secure, or error-free.
                            We do not warrant that the results that may be obtained from the use of the service will be accurate or reliable.
                            You agree that from time to time we may remove the service for indefinite periods of time or cancel the service at any time, without notice to you.
                            You expressly agree that your use of, or inability to use, the service is at your sole risk. The technologies, programs, and any type of service delivered to you through the service are (except as expressly stated by us) provided 'as is' and 'as available' for your use, without any representation, warranties, or conditions of any kind, either express or implied, including all implied warranties or conditions of merchantability, merchantable quality, fitness for a particular purpose, durability, title, and non-infringement.
                        </p>
                    </div>
                    <div>
                        <h5 className='terms-head' >Termination: </h5>
                        <p className='terms-content'>The obligations and liabilities of the parties incurred prior to the termination date shall survive the termination of this agreement for all purposes.
                            These Terms of Service are effective unless and until terminated by either you or us. You may terminate these Terms of Service at any time by notifying us that you no longer wish to use our Services, or when you cease using our site.
                            If in our sole judgment you fail, or we suspect that you have failed, to comply with any term or provision of these Terms of Service, we also may terminate this agreement at any time without notice and you will remain liable for all amounts due up to and including the date of termination; and/or accordingly may deny you access to our Services (or any part thereof).
                        </p>
                    </div>
                    <div>
                        <h5 className='terms-head' >Contact Information: </h5>
                        <p className='terms-content'>If you have any questions or concerns regarding these terms and conditions, please contact us at <a  style={{ textDecoration: "none", color: "#C76A97", fontSize: "20px" }}>info@techu.com</a> or <b style={{ color: "#C76A97" }}>040-40261333</b>. </p>
                    </div>
                </div>
                <div>
                <Footer />
            </div>
            </div>
        </>
    )
}

