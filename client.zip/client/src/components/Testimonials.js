import React, { useState } from 'react';
import { Navigation, Pagination, Scrollbar, A11y, Autoplay } from 'swiper/modules';
import { Swiper, SwiperSlide } from 'swiper/react';
import '../css/testimonials.css';
import { StarFill } from 'react-bootstrap-icons';


export default function Testimonials() {
    const [expandedReviews, setExpandedReviews] = useState({});

    const testimonials = [
        {
            image: "../images/profile-icon.png",
            title: "Front & Back-End Development",
            company: "../images/tcs.png",
            review: "I would like to express my heartfelt gratitude to TechU for providing an outstanding training program. The educators with their extensive expertise employed a hands-on approach that aided my understanding of complex ideas. The program considerably improved my technical skills, allowing me to gain a position in Accenture's R&D department. I am truly appreciative of their unwavering assistance. ",
            name: "Sakshi Kothari"
        },
        {
            image: "../images/profile-icon.png",
            title: "Business Analysis & Architecture",
            company: "../images/tcs.png",
            review: "TechU guidance and support were instrumental in shaping my career. Their amazing placement services enabled me to get a job  at Capgemini which was a perfect match for my talents and interests. The team at TechU took an active interest in learning about my career goals and provided personalized coaching throughout the training and placement process.",
            name: " Manas Kharge"

        },
        {
            image: "../images/profile-icon.png",
            title: "Data Science & Analytics",
            company: "../images/tcs.png",
            review: "I was fortunate to come across TechU, which provided career development services that proved invaluable in guiding me towards my objectives. With their help, I was able to identify my abilities, explore other career routes, and design a strategic plan for my professional development. Because of their consistent support, I am now working at Deloitte, which is aligned with my goals.",
            name: " Manpreet Kaur"

        },
        {
            image: "../images/profile-icon.png",
            title: "Digital Marketing",
            company: "../images/ibm (2).png",
            review: "I would like to express my heartfelt gratitude to TechU for providing an outstanding training program. The educators with their extensive expertise employed a hands-on approach that aided my understanding of complex ideas. The program considerably improved my technical skills, allowing me to gain a position in Accenture's R&D department. I am truly appreciative of their unwavering assistance.",
            name: "Sakshi Kothari"
        }, {
            image: "../images/profile-icon.png",
            title: "Front & Back-End Development",
            company: "../images/ibm (2).png",
            review: "I would like to express my heartfelt gratitude to TechU for providing an outstanding training program. The educators with their extensive expertise employed a hands-on approach that aided my understanding of complex ideas. The program considerably improved my technical skills, allowing me to gain a position in Accenture's R&D department. I am truly appreciative of their unwavering assistance ",
            name: " Manas Kharge"
        }
    ];
    const toggleReadMore = (index) => {
        setExpandedReviews((prevState) => ({
            ...prevState,
            [index]: !prevState[index],
        }));
    };

    return (
        <>
            <div className='row gx-0 justify-content-center testimonials'>
                <div className='testimonial'>
                    <p className='testimonialp '>Testimonials</p>
                    <h1 className='testimonialh1'>Our happy students say about us</h1>
                    <p className='testimonialtext-wrap'>
                        Our students are at the heart of everything we do. Their success stories are a testament to
                        our commitment to excellence in education. Hear what our happy students have to say about their experience with us.                   </p>
                </div>
                <div className="testimonial-card">

                    <Swiper

                        modules={[Navigation, Pagination, Scrollbar, A11y, Autoplay]}
                        spaceBetween={50}
                        autoplay={{
                            delay: 3000,
                            disableOnInteraction: false,

                        }}
                        pagination={{
                            dynamicBullets: true,
                        }}

                        breakpoints={{
                            640: {
                                slidesPerView: 1,

                            },
                            768: {
                                slidesPerView: 1,


                            },
                            1024: {
                                slidesPerView: 3,
                            },
                        }}
                    >
                        {
                            testimonials.map((testi, index) =>
                                <SwiperSlide key={index}>
                                    <div className='first-card'>
                                        <div className="card testimonials-card" style={{}}>
                                            <div className="card-body about-card">
                                                <div className="card-img-top testimonial-img d-flex ">
                                                    <div><img src={testi.image} className='testimonial-image' alt="..." width={50} /></div>
                                                    <div className='ps-3'>

                                                        <h5 className="card-title testimonial-name">{testi.name}</h5>
                                                        <p className="card-title testimonial-title">{testi.title}</p>

                                                    </div>
                                                </div>
                                                <div className='stars'>
                                                    <StarFill className='star' size={25} style={{ color: "#FF8A00" }} />
                                                    <StarFill className='star' size={25} style={{ color: "#FF8A00" }} />
                                                    <StarFill className='star' size={25} style={{ color: "#FF8A00" }} />
                                                    <StarFill className='star' size={25} style={{ color: "#FF8A00" }} />
                                                    <StarFill className='star' size={25} style={{ color: "grey" }} />
                                                </div>
                                                <p className="card-text testimonial-text ">{expandedReviews[index] ? testi.review : `${testi.review.slice(0, 150)}`}
                                                    {testi.review.length > 150 && (
                                                        <button
                                                            className="btn btn-link read-more-button"
                                                            onClick={() => toggleReadMore(index)}
                                                        >
                                                            {expandedReviews[index] ? 'Read Less' : 'Read More'}
                                                        </button>
                                                    )}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </SwiperSlide>
                            )
                        }
                    </Swiper>
                </div>
            </div>
        </>
    );
}
