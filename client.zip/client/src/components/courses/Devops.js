import TextField from '@mui/material/TextField';
import '../../css/preview.css'
import * as React from 'react';
import MenuItem from '@mui/material/MenuItem';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { grey, pink } from '@mui/material/colors';
import { Check2Circle, Clock, StarFill } from 'react-bootstrap-icons';
import axios from 'axios';
import FormHelperText from '@mui/material/FormHelperText';
import { BagCheck, PersonVideo2, Translate, Mortarboard, Window } from 'react-bootstrap-icons';
import Navbar from '../Navbar';
import Enrollform from '../Forms/Enrollform';
import apiUrl from '../../config';
import { PopupContext } from '../../PopupProvider';
import SuccessPopup from '../SuccessPopup';
import { Footer } from '../Footer';


export const Devops = () => {
    const { isPopup3Open, openPopup3, isPopup4Open } = React.useContext(PopupContext);
    const [details, setDetails] = React.useState({
        name: "",
        email: "",
        mobile: "",
        course: "",
        message: ""
    })
    const [errors, setErrors] = React.useState("")
    const [devopsBatches, setDevopsBatches] = React.useState([]);
    const [isFieldFocused, setIsFieldFocused] = React.useState(false);

    const onFormSubmit = (e) => {
        e.preventDefault()
    }

    const onChangeFormData = (e) => {
        try {
            let name = e.target.name;
            let value = e.target.value;
            if (name === 'mobile') {
                if (value.length > 10) {
                    value = value.slice(0, 10);
                }
            }
            setDetails((ps) => ({ ...ps, [name]: value }))
        } catch (e) {
            console.log(e)
        }
    }

    const onSubmitFormData = async () => {
        try {
          const response = await fetch(`${apiUrl}/enquiry`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(details),
            credentials: 'omit',
          });
      
          if (response.status === 200) {
            setDetails({
              name: "",
              email: "",
              mobile: "",
              course: "",
              message: ""
            });
          } else {
            const errorData = await response.json();
            setErrors(errorData.message);
          }
        } catch (error) {
          console.log(error);
        }
      };
      
      const getAllBatches = async () => {
        try {
          const response = await fetch(`${apiUrl}/batches/all`);
          if (response.ok) {
            const allBatches = await response.json();
            setDevopsBatches(allBatches.filter(batch => batch.title === "Devops"));
          } else {
            throw new Error('Network response was not ok');
          }
        } catch (error) {
          console.log(error);
        }
      };
      
    const courselist = ['MERN STACK', 'MEAN STACK', 'DATA SCIENCE', 'DEVOPS']


    let
        formtheme = createTheme({
            palette: {
                primary: {
                    main: pink[200],
                },
                secondary: {
                    main: grey[500],
                },
            },
        });



   

    React.useEffect(() => {
        getAllBatches();
    }, []);

    const [batchdata, setBatchdata] = React.useState()

    const handleBatch = (batch) => {
        setBatchdata(batch)
    }

    const today = new Date()
    const day = String(today.getDate()).padStart(2, '0');
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const year = today.getFullYear();
    const todayDate = `${year}yyyy-${month}mm-${day}dd`;
    function filterdArray() {
        devopsBatches.forEach((val) => {
            const givenDate = new Date(val.startdate)
            const givenday = String(givenDate.getDate()).padStart(2, '0');
            const givenmonth = String(givenDate.getMonth() + 1).padStart(2, '0');
            const givenyear = givenDate.getFullYear();
            const givenDateformate = `${givenyear}yyyy-${givenmonth}mm-${givenday}dd`;
            if (todayDate >= givenDateformate) {
                let index = devopsBatches.indexOf(val)
                devopsBatches.splice(index, 1)
            }
        })
    }
    filterdArray()
    return (
        <div>
            <Navbar />
            <div className='preview-head row gx-0 '>
                <div className='head-text col-lg-6 col-md-6 col-sm-12 ps-3'>
                    <h2 className='preview-heading '> Devops Training</h2>
                    <p className='head-content  pt-3'>The DevOps is a combination of two words, one is software Development, and second is Operations. This allows a single team to handle the entire application lifecycle, from development to testing, deployment, and operations. DevOps helps you to reduce the disconnection between software developers, quality assurance (QA) engineers, and system administrators. </p>
                    <div className='row review-star justify-content-around'>
                        <div className='col-lg-5 col-sm-12 float-btn1 '>
                            <button className='preview-btn '>Download</button>
                        </div>
                        <div className='review d-flex   col-lg-7 col-sm-12'>
                            <div className='review-rating pe-2 '>
                                <span>4.0</span>
                                <StarFill className='star ms-2' size={25} style={{ color: '#FF8A00' }} />
                                <StarFill className='star ms-2' size={25} style={{ color: '#FF8A00' }} />
                                <StarFill className='star ms-2' size={25} style={{ color: '#FF8A00' }} />
                                <StarFill className='star ms-2' size={25} style={{ color: '#FF8A00' }} />
                                <StarFill className='star ms-2' size={25} style={{ color: 'grey' }} />
                            </div>
                            <div className='views d-flex justify-content-center'>
                                <p className='reviews-p ps-2 pt-3'>120 reviews</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='head-img  col-lg-6 col-md-6 col-sm-12 '>
                    <img className="img-head " src="../images/MicrosoftTeams-image.png" width={"100%"} alt='' />
                </div>
            </div>
            <nav className='nav-sticky'>
                <div className='course-nav '>
                    <div className='nav-main'>
                        <ul className="nav">
                            <li className="nav-itemm">
                                <a className="nav-link " aria-current="page" href="#overview">Overview</a>
                            </li>
                            <li className="nav-itemm">
                                <a className="nav-link" href="#schedule">Schedule</a>
                            </li>
                            <li className="nav-itemm">
                                <a className="nav-link" href="#syllabus">Syllabus</a>
                            </li>
                            <li className="nav-itemm">
                                <a className="nav-link" href="#certificate" tabindex="-1" aria-disabled="true">Certificate</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div className='overview row g-0' id="overview">
                <div className='col-lg-8 col-md-12 col-sm-12'>
                    <div className='overview-main' >
                        <div>
                            <h4 className='course-overview'>Course Overview</h4>
                            <p className='overview-text'>
                                Bringing developers (dev) and operations (ops) together within teams is called Devops (development + Operations). Deploying the code in cloud (like AWS) by using Devops tools  (like Jenkins etc) and using operating system Linux ( it is Command Line Interface) and Monitoring applications and infrastructure.
                            </p>
                        </div>
                        <div className='why-learn'>
                            <h4 className='course-learn'>Why Learn Devops?</h4>
                            <div className='learn'>
                                <h6 className='course-used'>Widely used</h6>
                                <p className='course-learn-text'>Learning DevOps ensures that there is a reduction in rollbacks, failures regarding deployment and also the time is taken to recover.</p>
                                <h6 className='course-used'>Lucrative Salary</h6>
                                <p className='course-learn-text'>The average salary for a DevOps Engineers  is 6 LPA+ according to Indeed.</p>
                                <h6 className='course-used'>Create with Ease</h6>
                                <p className='course-learn-text'>Faster, better product delivery.Faster issue resolution and reduced complexity.Greater scalability and availability. </p>
                            </div>
                            <h4 className='course-learn'>Key Features</h4>
                            <ul className='course-li'>
                                <li>DevOps is more or less a very new concept in the industry and more and more companies are deploying DevOps practices.
                                </li>
                                <li>A DevOps certification will expand your horizon as an IT professional and better job opportunities will come your way.</li>
                                <li>
                                    The DevOps ideology encourages a complete new way of thinking and decision-making. The business and technical benefits of DevOps.</li>
                                <li>
                                    Everyone likes to be productive at work and the time you waste waiting is sure to cause frustration.</li>
                            </ul>
                            <h4 className='course-learn'>Skills you'll gain</h4>
                            <div className='skills-ul'>
                                <p className='skills'>Linux</p>
                                <p className='skills'>Github</p>
                                <p className='skills'>Maven</p>
                                <p className='skills'>Jenkins</p>
                                <p className='skills'>Docker</p>
                                <p className='skills'>Kubernetes</p>
                                <p className='skills'>Shell Scripting</p>
                                <p className='skills'>AWS cloud</p>
                            </div>
                        </div>
                    </div>
                    <div className='schedule-container row g-0'>
                        <div id='schedule'>
                            <h4 className='schedule'>Schedules for DevOps Training</h4>
                            <p className='schedule-text'>Create your own customizable, full-featured applications using the flexible and reliable Develop.</p>
                            <div className=''>
                                {
                                    devopsBatches.map(batch => {
                                        const startDate = new Date(batch.startdate);
                                        const startMonth = startDate.toLocaleString('default', { month: 'short' });
                                        const startDay = startDate.getDate();
                                        const year = startDate.getFullYear();
                                        return (
                                            <div className='' key={batch.id}>
                                                <div className='schedule-content'>
                                                    <div className='batche-main col-lg-11'>
                                                        <span className='date'>  <span className='schedule-date'>Batch starts on {`${startMonth} ${startDay} ${year}`}</span></span>
                                                        <h4 className='schedule-h4'>{batch.title}</h4>
                                                        <div className=''>
                                                            <div className='schedule-main'>
                                                                <div className='schedule-content'>
                                                                    <div className='schedule-1'>
                                                                        <div className='schedule-head'>
                                                                            <div className='schedule-icon'>
                                                                                <span><Clock size={20} className='chech2circle  ' /></span>
                                                                            </div>
                                                                            <div className='schedule-timing'>
                                                                                <p className='schedule-time'>Timing</p>
                                                                                <p className='schedule-time1'>{batch.timing} </p>
                                                                            </div>
                                                                        </div>
                                                                        <div className='schedule-head'>
                                                                            <div className='schedule-icon'>
                                                                                <span><Window size={20} className='chech2circle  ' /></span>
                                                                            </div>
                                                                            <div className='schedule-timing'>
                                                                                <p className='schedule-time'>Mode</p>
                                                                                <p className='schedule-time1'>Offline & Online</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div className='schedule-1' >
                                                                        <div className='schedule-head'>
                                                                            <div className='schedule-icon'>
                                                                                <span><PersonVideo2 size={20} className='chech2circle  ' /></span>
                                                                            </div>
                                                                            <div className='schedule-timing'>
                                                                                <p className='schedule-time'>Trainer:</p>
                                                                                <p className='schedule-time1'>{batch.trainer} </p>
                                                                            </div>
                                                                        </div>
                                                                        <div className='schedule-head'>
                                                                            <div className='schedule-icon'>
                                                                                <span><Translate size={20} className='chech2circle  ' /></span>
                                                                            </div>
                                                                            <div className='schedule-timing'>
                                                                                <p className='schedule-time'>Language:</p>
                                                                                <p className='schedule-time1'>English </p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div className='schedule-1'>
                                                                        <div className='schedule-head'>
                                                                            <div className='schedule-icon'>
                                                                                <span><Mortarboard size={20} className='chech2circle  ' /></span>
                                                                            </div>
                                                                            <div className='schedule-timing'>
                                                                                <p className='schedule-time'>Course Duration:</p>
                                                                                <p className='schedule-time1'>{batch.courseduration} Months</p>
                                                                            </div>
                                                                        </div>
                                                                        <div className='schedule-head'>
                                                                            <div className='schedule-icon'>
                                                                                <span><BagCheck size={20} className='chech2circle  ' /></span>
                                                                            </div>
                                                                            <div className='schedule-timing'>
                                                                                <p className='schedule-time'>Internship:</p>
                                                                                <p className='schedule-time1'>{batch.internship} Months</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className='schedule-btns' >
                                                                    <div className='schedule-enroll'>

                                                                        <button className='schedule-btn' onClick={() => { openPopup3(); handleBatch(batch) }} style={{ color: "#ffffff" }} >ENROLL NOW</button>


                                                                        {isPopup3Open && <Enrollform batch={batchdata} />}

                                                                        {isPopup4Open && <SuccessPopup />}


                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        )
                                    })
                                }
                            </div>
                        </div>
                    </div>
                    <div className=' syllabus-main row g-0 ' id='syllabus'>
                        <div className='curiculum col-lg-12'>
                            <p className='syllabus'>DevOps Training Syllabus</p>
                            <div className="accordion" id="accordionExample">
                                <div className="accordion-item  m-2">
                                    <h2 className="accordion-header     ">
                                        <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            <p className='faq'>Linux</p>
                                        </button>
                                    </h2>
                                    <div id="collapseOne" className="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                                        <div className="accordion-body ">
                                            <ul className='curriculum-content'>
                                                <li>Linux OS Introduction </li>
                                                <li>Importance of Linux in DevOps </li>
                                                <li>Linux Basic Command Utilities </li>
                                                <li>Linux Administration </li>
                                                <li>Linux Server Installation, RPM and YUM Installation </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div className="accordion-item  m-2">
                                    <h2 className="accordion-header     ">
                                        <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                            <p className='faq'>GIT – A Version controlling tool  </p>
                                        </button>
                                    </h2>
                                    <div id="collapseTwo" className="accordion-collapse collapse collapse" data-bs-parent="#accordionExample">
                                        <div className="accordion-body ">
                                            <ul className='curriculum-content'>
                                                <li>Knowing about Version control  </li>
                                                <li>Git – A CLI  </li>
                                                <li>How to setup GIT   </li>
                                                <li>Recording Changes to the Repository   </li>
                                                <li>Working with Remotes   </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div className="accordion-item  m-2">
                                    <h2 className="accordion-header     ">
                                        <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                            <p className='faq'>Jenkins  </p>
                                        </button>
                                    </h2>
                                    <div id="collapseThree" className="accordion-collapse collapse collapse" data-bs-parent="#accordionExample">
                                        <div className="accordion-body ">
                                            <ul className='curriculum-content'>
                                                <li> Essentials of Continuous Integration </li>
                                                <li>Know about Jenkins and its architecture in detail  </li>
                                                <li>Jenkins tool Management in detail  </li>
                                                <li>Authentication  </li>
                                                <li>Overview of Maven  </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div className="accordion-item  m-2">
                                    <h2 className="accordion-header     ">
                                        <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                            <p className='faq'>Docker  </p>
                                        </button>
                                    </h2>
                                    <div id="collapseFour" className="accordion-collapse collapse collapse" data-bs-parent="#accordionExample">
                                        <div className="accordion-body ">
                                            <ul className='curriculum-content'>
                                                <li>Introduction, Working with container </li>
                                                <li>Introduction to Docker Networking </li>
                                                <li>Docker Swarm – An introduction </li>
                                                <li>Kubernetes   </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='social row g-0'>
                        <div className='social-media col-lg-12'>
                            <p className='project'>DevOps Course Projects Details</p>
                            <div className='d-flex'>
                                <div> <span><Check2Circle className='chech2circle' size={20} /></span></div>
                                <div className='social-main'>
                                    <h4 className='social-links'>Jenkins Project CI/CD</h4>
                                    <p className='social-text'>In this project we build a pipeline using tools like Git,Maven and Apache Tomcat. we will deploy a javaweb application in tomcat server </p>
                                </div>
                            </div>
                            <div className='d-flex'>
                                <div> <span><Check2Circle className='chech2circle' size={20} /></span></div>
                                <div className='social-main'>
                                    <h4 className='social-links'>Containerization of Java Project using Docker</h4>
                                    <p className='social-text'> In this project we build the docker images and containers from java based applications. </p>
                                </div>
                            </div>
                            <div className='d-flex'>
                                <div> <span><Check2Circle className='chech2circle' size={20} /></span></div>
                                <div className='social-main'>

                                    <h4 className='social-links'>Deploying Application Using Kubernetes</h4>
                                    <p className='social-text'> You will learn how to create Kubernetes objects such as deployments, services, and secrets.You will also learn how to access and monitor your application using Kubernetes Dashboard. </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className=' form-main col-lg-4 col-md-12 col-sm-12  '>

                    <div className='preview-formm  p-3 '>
                        <h6 className='form-h6'>Request for more details</h6>
                        <form className='' onSubmit={onFormSubmit}>
                            <ThemeProvider theme={formtheme}>
                                <TextField id="outlined-basic" className='fields mt-3 w-100' name='name' value={details.name} onChange={onChangeFormData} onFocus={() => setIsFieldFocused(true)}
                                    onBlur={() => setIsFieldFocused(false)} type='text' label=" Name" variant="outlined" />
                                <FormHelperText style={{ color: 'red' }}>
                                    {isFieldFocused ? "" : (errors === "please enter the name") ? "Enter a Valid Name" : ""}</FormHelperText>
                                <TextField id="outlined-basic" className='fields mt-3 w-100 ' name='email' value={details.email} onChange={onChangeFormData} label="E-Mail" type='email' onFocus={() => setIsFieldFocused(true)}
                                    onBlur={() => setIsFieldFocused(false)} variant="outlined" />
                                <FormHelperText style={{ color: 'red' }}>
                                    {isFieldFocused ? "" : (errors === "Please enter the email") ? "Enter a Valid Email" : ""}</FormHelperText>
                                <FormHelperText style={{ color: 'red' }}>
                                    {isFieldFocused ? "" : (errors === "Invalid Email") ? "Enter a Valid Email" : ""}</FormHelperText>
                                <FormHelperText style={{ color: 'red' }}>
                                    {isFieldFocused ? "" : (errors === "You have been already Enrolled") ? "Enter a Valid Email" : ""}</FormHelperText>
                                <TextField id="outlined-basic" className='fields mt-3 w-100 ' name='mobile' value={details.mobile}
                                    inputProps={{
                                        maxLength: 10,
                                    }}
                                    onFocus={() => setIsFieldFocused(true)}
                                    onBlur={() => setIsFieldFocused(false)} onChange={onChangeFormData} type='number' label="Moblie" variant="outlined" />
                                <FormHelperText style={{ color: 'red' }}>
                                    {isFieldFocused ? "" : (errors === "Please Enter Phone Number") ? "Enter a Valid Mobile Number" : ""}</FormHelperText>
                                <FormHelperText style={{ color: 'red' }}>
                                    {isFieldFocused ? "" : (errors === "Enter valid phone number") ? "Enter a Valid Mobile Number" : ""}</FormHelperText>
                                <FormControl sx={{ color: 'black' }} className='mt-3 w-100'>
                                    <InputLabel id="demo-simple-select-autowidth-label" className=' w-100'>Course</InputLabel>
                                    <Select
                                        name="course"
                                        labelId="demo-simple-select-autowidth-label"
                                        id="demo-simple-select-autowidth"
                                        value={details.course}
                                        onChange={onChangeFormData}
                                        autoWidth
                                        label="course"
                                        onFocus={() => setIsFieldFocused(true)}
                                        onBlur={() => setIsFieldFocused(false)}
                                    >
                                        {
                                            courselist.map((course) => (
                                                <MenuItem value={course} >{course}</MenuItem>))
                                        }
                                    </Select>
                                </FormControl>
                                <FormHelperText style={{ color: 'red' }}>
                                    {isFieldFocused ? "" : (errors === "Please Select Course") ? "Select a Course" : ""}</FormHelperText>
                                <TextField id="outlined-basic" className='fields mt-3 w-100' multiline minRows={3} name='message' value={details.message} onChange={onChangeFormData} type='text' label="Message" variant="outlined" />
                            </ThemeProvider>
                            <div className='d-flex justify-content-center mt-4 '>
                                <button className='preview-btn px-4 py-1' onClick={onSubmitFormData}>Submit</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
            <div className='certi-main ' id="certificate">
                <div className='certi-container row g-0'>
                    <div className='certi-content col-lg-6'>
                        <span className='certi'>Industry recognized & government approved Develop certification</span>
                        <p className='certi-text'>Angular JS was built on the concept of efficiency of performance and fast responses, and it has been very useful in single-page application development, because it is easy to use and completely free, making it accessible to programmers across the world.</p>
                    </div>
                    <div className='certi-certi col-lg-6'>
                        <img className=" " src="../images/cert.svg" width={"100%"} alt='' />
                    </div>
                </div>
            </div>
            <div>
                {/* {isPopup2Open && <SuccessPopup />} */}
            </div>
            <div>
                <Footer />
            </div>
        </div>
    )
}

