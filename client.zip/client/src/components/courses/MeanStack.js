import TextField from '@mui/material/TextField';
import '../../css/preview.css'
import * as React from 'react';
import MenuItem from '@mui/material/MenuItem';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { grey, pink } from '@mui/material/colors';
import { Check2Circle, Clock, StarFill } from 'react-bootstrap-icons';
import axios from 'axios';
import FormHelperText from '@mui/material/FormHelperText';
import { BagCheck, PersonVideo2, Translate, Mortarboard, Window } from 'react-bootstrap-icons';
import Navbar from '../Navbar';
import Enrollform from '../Forms/Enrollform';
import apiUrl from '../../config';
import SuccessPopup from '../SuccessPopup';
import { PopupContext } from '../../PopupProvider';
import { Footer } from '../Footer';


const MeanStack = () => {

    const { isPopup3Open, openPopup3, isPopup4Open } = React.useContext(PopupContext);

    const [details, setDetails] = React.useState({
        name: "",
        email: "",
        mobile: "",
        course: "",
        message: ""
    })
    const [errors, setErrors] = React.useState("")
    const [meanStackBatches, setMeanStackBatches] = React.useState([]);
    const [isFieldFocused, setIsFieldFocused] = React.useState(false);
    // const [successtext, setSuccesstext]=React.useState()

    const onFormSubmit = (e) => {
        e.preventDefault()
    }

    const onChangeFormData = (e) => {
        try {
            let name = e.target.name;
            let value = e.target.value;
            if (name === 'mobile') {
                if (value.length > 10) {
                    value = value.slice(0, 10);
                }
            }
            setDetails((ps) => ({ ...ps, [name]: value }))
        } catch (e) {

        }
    }

    const onSubmitFormData = async () => {
        try {
            const response = await fetch(apiUrl + '/enquiry', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(details),
                credentials: 'omit',
            });
    
            if (response.status === 200) {
                setDetails({
                    name: "",
                    email: "",
                    mobile: "",
                    course: "",
                    message: ""
                });
            }
        } catch (e) {
            const errorResponse = await e.json();
            setErrors(errorResponse.message);
        }
    }
    
    const getAllBatches = async () => {
        try {
            const response = await fetch(apiUrl + '/batches/all');
    
            if (response.ok) {
                const allBatches = await response.json();
                setMeanStackBatches(allBatches.filter(batch => batch.title === 'Mean Stack'));
            } else {
                console.log('Error:', response.status);
            }
        } catch (error) {
            console.log(error);
        }
    }
    
    const courselist = ['MERN STACK', 'MEAN STACK', 'DATA SCIENCE', 'DEVOPS']
    let formtheme = createTheme({
            palette: {
                primary: {
                    main: pink[200],
                },
                secondary: {
                    main: grey[500],
                },
            },
        });

   

    React.useEffect(() => {
        getAllBatches();
    }, []);

    const [batchdata, setBatchdata] = React.useState()

    const handleBatch = (batch) => {
        setBatchdata(batch)
    }

    const today = new Date()
    const day = String(today.getDate()).padStart(2, '0');
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const year = today.getFullYear();
    const todayDate = `${year}yyyy-${month}mm-${day}dd`;
    function filterdArray() {
        meanStackBatches.forEach((val) => {
            const givenDate = new Date(val.startdate)
            const givenday = String(givenDate.getDate()).padStart(2, '0');
            const givenmonth = String(givenDate.getMonth() + 1).padStart(2, '0');
            const givenyear = givenDate.getFullYear();
            const givenDateformate = `${givenyear}yyyy-${givenmonth}mm-${givenday}dd`;
            if (todayDate >= givenDateformate) {
                let index = meanStackBatches.indexOf(val)
                meanStackBatches.splice(index, 1)
            }
        })
    }
    filterdArray()

    return (

        <div>
            <Navbar />

            <div className='preview-head row gx-0 '>
                <div className='head-text col-lg-6 col-md-6 col-sm-12 ps-3'>
                    <h2 className='preview-heading '> Mean Stack Training</h2>
                    <p className='head-content  pt-3'>MEAN stack training provides a comprehensive learning experience in web development.
                        It encompasses MongoDB for database management, Express.js for server-side logic, React for creating dynamic user interfaces,
                        and Node.js for server runtime. This training typically covers full-stack development, authentication, deployment, and real-time features. It equips individuals with the expertise needed
                        to build modern, scalable web applications efficiently using this popular technology stack.</p>
                    <div className='row review-star justify-content-around '>
                        <div className='col-lg-5 col-sm-12 float-btn1 '>
                            <button className='preview-btn '>Download</button>
                        </div>
                        <div className='review d-flex   col-lg-7 col-sm-12'>
                            <div className='review-rating pe-2 '>
                                <span>4.0</span>
                                <StarFill className='star ms-2' size={25} style={{ color: '#FF8A00' }} />
                                <StarFill className='star ms-2' size={25} style={{ color: '#FF8A00' }} />
                                <StarFill className='star ms-2' size={25} style={{ color: '#FF8A00' }} />
                                <StarFill className='star ms-2' size={25} style={{ color: '#FF8A00' }} />
                                <StarFill className='star ms-2' size={25} style={{ color: 'grey' }} />
                            </div>
                            <div className='views d-flex justify-content-center'>
                                <p className='reviews-p ps-2 pt-3'>120 reviews</p>
                            </div>
                        </div>

                    </div>
                </div>
                <div className='head-img  col-lg-6 col-md-6 col-sm-12 '>
                    <img className="img-head " src="../images/previewimg.png" width={"100%"} alt='' />
                </div>
            </div>
            <nav className='nav-sticky'>
                <div className='course-nav '>
                    <div className='nav-main'>
                        <ul className="nav">
                            <li className="nav-itemm">
                                <a className="nav-link " aria-current="page" href="#overview">Overview</a>
                            </li>
                            <li className="nav-itemm">
                                <a className="nav-link" href="#schedule">Schedule</a>
                            </li>
                            <li className="nav-itemm">
                                <a className="nav-link" href="#syllabus">Syllabus</a>
                            </li>
                            <li className="nav-itemm">
                                <a className="nav-link" href="#certificate" tabindex="-1" aria-disabled="true">Certificate</a>
                            </li>
                        </ul>
                    </div>

                </div>
            </nav>
            <div className='overview row g-0' id="overview">
                <div className='col-lg-8 col-md-12 col-sm-12'>
                    <div className='overview-main' >
                        <div>
                            <h4 className='course-overview'>Course Overview</h4>
                            <p className='overview-text'>
                                Mean Stack was built on the concept of efficiency of performance and fast responses, and it has been very useful in single-page application development, because it is easy to use and completely free, making it accessible to programmers across the world. Mean Stack certification courses are in high demand for their prominence in front-end web development and our courses offer a comprehensive understanding of the concepts of Mean Stack by using a thorough and extensive curriculum.
                            </p>
                        </div>
                        <div className='why-learn'>
                            <h4 className='course-learn'>Why Learn Mean Stack?</h4>
                            <div className='learn'>
                                <h6 className='course-used'>Widely used</h6>
                                <p className='course-learn-text'>Mean Stack is the most widely used Javascript framework for building web, desktop, and mobile applications.</p>
                                <h6 className='course-used'>Lucrative Salary</h6>
                                <p className='course-learn-text'>The average salary for a Front End Developer is 6 LPA+ according to Indeed.</p>
                                <h6 className='course-used'>Create with Ease</h6>
                                <p className='course-learn-text'>Create your own customizable, full-featured applications using the flexible and reliable interface of the React framework.</p>
                            </div>
                            <h4 className='course-learn'>Key Features</h4>
                            <ul className='course-li'>
                                <li>Quick, easy to use the structure for understanding the framework.
                                </li>
                                <li>Structured and organized interface.</li>
                                <li>
                                    Useful in understanding concepts for creating multiple views for single-page applications.</li>
                                <li>
                                    Offer in-depth experience in dealing with binding of different components and models</li>
                            </ul>
                            <h4 className='course-learn'>Skills you'll gain</h4>
                            <div className='skills-ul'>
                                <p className='skills'>HTML5</p>
                                <p className='skills'>CSS</p>
                                <p className='skills'>JavaScript</p>
                                <p className='skills'>Bootstrap</p>
                                <p className='skills'>Mean Stack</p>
                                <p className='skills'>NodeJs</p>
                                <p className='skills'>ExpressJS</p>
                                <p className='skills'>MongoDB</p>
                            </div>
                        </div>
                    </div>
                    <div className='schedule-container row g-0' id='schedule'>
                        <div id='schedule'>
                            <h4 className='schedule'>Schedules for Mean Stack Training</h4>
                            <p className='schedule-text'>Create your own customizable, full-featured applications using the flexible and reliable interface of the React framework.</p>
                            <div className=''>
                                {
                                    meanStackBatches.map(batch => {
                                        const startDate = new Date(batch.startdate);
                                        const startMonth = startDate.toLocaleString('default', { month: 'short' });
                                        const startDay = startDate.getDate();
                                        const year = startDate.getFullYear();
                                        return (

                                            <div className='' key={batch.id}>
                                                <div className='schedule-content'>
                                                    <div className='batche-main col-lg-11'>
                                                        <span className='date'>  <span className='schedule-date'>Batch starts on {`${startMonth} ${startDay} ${year}`}</span></span>
                                                        <h4 className='schedule-h4'>{batch.title}</h4>
                                                        <div className=''>
                                                            <div className='schedule-main'>
                                                                <div className='schedule-content'>
                                                                    <div className='schedule-1'>
                                                                        <div className='schedule-head'>
                                                                            <div className='schedule-icon'>
                                                                                <span><Clock size={20} className='chech2circle  ' /></span>
                                                                            </div>
                                                                            <div className='schedule-timing'>
                                                                                <p className='schedule-time'>Timing</p>
                                                                                <p className='schedule-time1'>{batch.timing} </p>
                                                                            </div>
                                                                        </div>
                                                                        <div className='schedule-head'>
                                                                            <div className='schedule-icon'>
                                                                                <span><Window size={20} className='chech2circle  ' /></span>
                                                                            </div>
                                                                            <div className='schedule-timing'>
                                                                                <p className='schedule-time'>Mode</p>
                                                                                <p className='schedule-time1'>Offline & Online</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div className='schedule-1' >
                                                                        <div className='schedule-head'>
                                                                            <div className='schedule-icon'>
                                                                                <span><PersonVideo2 size={20} className='chech2circle  ' /></span>
                                                                            </div>
                                                                            <div className='schedule-timing'>
                                                                                <p className='schedule-time'>Trainer:</p>
                                                                                <p className='schedule-time1'>{batch.trainer} </p>
                                                                            </div>
                                                                        </div>
                                                                        <div className='schedule-head'>
                                                                            <div className='schedule-icon'>
                                                                                <span><Translate size={20} className='chech2circle  ' /></span>
                                                                            </div>
                                                                            <div className='schedule-timing'>
                                                                                <p className='schedule-time'>Language:</p>
                                                                                <p className='schedule-time1'>English </p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div className='schedule-1'>
                                                                        <div className='schedule-head'>
                                                                            <div className='schedule-icon'>
                                                                                <span><Mortarboard size={20} className='chech2circle  ' /></span>
                                                                            </div>
                                                                            <div className='schedule-timing'>
                                                                                <p className='schedule-time'>Course Duration:</p>
                                                                                <p className='schedule-time1'>{batch.courseduration} Months</p>
                                                                            </div>
                                                                        </div>
                                                                        <div className='schedule-head'>
                                                                            <div className='schedule-icon'>
                                                                                <span><BagCheck size={20} className='chech2circle  ' /></span>
                                                                            </div>
                                                                            <div className='schedule-timing'>
                                                                                <p className='schedule-time'>Internship:</p>
                                                                                <p className='schedule-time1'>{batch.internship} Months</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className='schedule-btns' >
                                                                    <div className='schedule-enroll'>
                                                                        <button className='schedule-btn' onClick={() => { openPopup3(); handleBatch(batch) }} style={{ color: "#ffffff" }} >ENROLL NOW</button>


                                                                        {isPopup3Open && <Enrollform batch={batchdata} />}

                                                                        {isPopup4Open && <SuccessPopup  />}

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        )
                                    })
                                }
                            </div>
                        </div>
                    </div>
                    <div className=' syllabus-main row g-0 ' id='syllabus'>
                        <div className='curiculum '>
                            <p className='syllabus'>Mean Stack Training Syllabus</p>
                            <div className="accordion" id="accordionExample">
                                <div className="accordion-item m-2">
                                    <h2 className="accordion-header">
                                        <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            <p className='faq'>HTML</p>
                                        </button>
                                    </h2>
                                    <div id="collapseOne" className="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                                        <div className="accordion-body">
                                            <ul className='curriculum-content'>
                                                <li>Technologies around HTML Basics of HTML</li>
                                                <li>Heading tags(H1...H6), Tags and attributes(Class, Id, style..etc) </li>
                                                <li>Inline and block-level elements HTML Tagsgit  </li>
                                                <li>Layouts, forms, buttons ,Input fields ( text box, radio button, checkbox, dropdown, text area etc) HTML5 </li>
                                                <li>Storing user preferences using LocalStorage. Form Elements, List of Browsers support HTML5 </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div className="accordion-item m-2">
                                    <h2 className="accordion-header">
                                        <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                            <p className='faq '>CSS</p>
                                        </button>
                                    </h2>
                                    <div id="collapseTwo" className="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                        <div className="accordion-body">
                                            <ul className='curriculum-content'>
                                                <li>CSS properties, Adding borders, font, pseudo classes</li>
                                                <li>Positioning elements (absolute, relative, fixed and static) </li>
                                                <li>Box model (margins, padding), Floating elements (float left, right etc.) </li>
                                                <li> Positions, Adding Transitions to elements,Responsive Designs </li>
                                                <li>Difference between multiple devices, making a page to work on multiple devices </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div className="accordion-item m-2">
                                    <h2 className="accordion-header">
                                        <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                            <p className='faq mt-3'>Bootstrap </p>
                                        </button>
                                    </h2>
                                    <div id="collapseThree" className="accordion-collapse  collapse" data-bs-parent="#accordionExample">
                                        <div className="accordion-body">
                                            <ul className='curriculum-content'>
                                                <li>What is Bootstrap Framework, Advantages of Bootstrap Framework,  Responsive web page </li>
                                                <li>What is Container, What is Offset Column, How to change class properties </li>
                                                <li>How to use Button Groups and Button Toolbar </li>
                                                <li>What are different Input Groups Components, Navigation Pills & Tabs Components  </li>
                                                <li>How to Create Progress Bar, Media Objects Component  </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                <div className="accordion-item m-2">
                                    <h2 className="accordion-header">
                                        <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                            <p className='faq'>JavaScript </p>
                                        </button>
                                    </h2>
                                    <div id="collapseFour" className="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                        <div className="accordion-body">
                                            <ul className='curriculum-content'>
                                                <li>Introduction, Data types and data structures in Js, Control structures,</li>
                                                <li>Document Object Model (DOM), Arrays & Objects, Advanced JavaScript ES6  </li>
                                                <li>Classes, Properties and Methods, The Spread & Rest Operator, Destructuring  </li>
                                                <li> Next-Gen JavaScript - Summary, JS Array Functions  </li>
                                                <li>Predefined methods in arrays, Strings and predefined methods  </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div className="accordion-item m-2">
                                    <h2 className="accordion-header">
                                        <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                            <p className='faq'>Mean Stack  </p>
                                        </button>
                                    </h2>
                                    <div id="collapseFive" className="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                        <div className="accordion-body">
                                            <ul className='curriculum-content'>
                                                <li>Mean Stack Introduction, Text BoxFirst React Code React Alternatives </li>
                                                <li>Create React App Folder Structure, Functional Component Working with Props   </li>
                                                <li>Class Components, Hooks, Api Integrations, Functions  </li>
                                                <li> Routes, React-Document Object Modal  </li>
                                                <li>Project with Axios, Http Request to GET Data, Fetching Data on Update, POSTing Data to the Server   </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div className="accordion-item m-2">
                                    <h2 className="accordion-header">
                                        <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                            <p className='faq'>MongoDB  </p>
                                        </button>
                                    </h2>
                                    <div id="collapseSix" className="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                        <div className="accordion-body">
                                            <ul className='curriculum-content'>
                                                <li>Installing Mongoose, Understanding Models & Schemas  </li>
                                                <li>Connecting React to a Database, Setting Up MongoDB </li>
                                                <li>Connecting to the Database & Saving the Product, Getting Products</li>
                                                <li> Creating & Storing Documents in the Database, Sending a POST Request to the Backend   </li>
                                                <li>Creating a Custom Http Hook, Improving the Custom Http Hook </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className='social row g-0'>
                        <div className='social-media col-lg-12'>
                            <p className='project'>Mean Stack Course Projects Details</p>
                            <div className='d-flex'>
                                <div> <span><Check2Circle className='chech2circle' size={20} /></span></div>
                                <div className='social-main'>
                                    <h4 className='social-links'>Social blogging website</h4>
                                    <p className='social-text'> Build a social blogging platform that allows users to log in, create their profile, and post. </p>
                                </div>
                            </div>
                            <div className='d-flex'>
                                <div> <span><Check2Circle className='chech2circle' size={20} /></span></div>
                                <div className='social-main'>
                                    <h4 className='social-links'>Voter verification app</h4>
                                    <p className='social-text'> Create a simple voter app that takes name and age as input and tells users whether they are eligible or not. </p>
                                </div>
                            </div>
                            <div className='d-flex'>
                                <div> <span><Check2Circle className='chech2circle' size={20} /></span></div>
                                <div className='social-main'>
                                    <h4 className='social-links'>Interest calculator</h4>
                                    <p className='social-text'> Build an interest calculator that displays simple interest based on the input value. </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className=' form-main col-lg-4 col-md-12 col-sm-12  '>

                    <div className='preview-formm  p-3  '>
                        <h6 className='form-h6'>Request for more details</h6>
                        <form className='' onSubmit={onFormSubmit}>
                            <ThemeProvider theme={formtheme}>

                                <TextField id="outlined-basic" className='fields mt-3 w-100' name='name' value={details.name} onChange={onChangeFormData} onFocus={() => setIsFieldFocused(true)}
                                    onBlur={() => setIsFieldFocused(false)} type='text' label=" Name" variant="outlined" />
                                <FormHelperText style={{ color: 'red' }}>
                                    {isFieldFocused ? "" : (errors === "please enter the name") ? "Enter a Valid Name" : ""}</FormHelperText>
                                <TextField id="outlined-basic" className='fields mt-3 w-100 ' name='email' value={details.email} onChange={onChangeFormData} label="E-Mail" type='email' onFocus={() => setIsFieldFocused(true)}
                                    onBlur={() => setIsFieldFocused(false)} variant="outlined" />
                                <FormHelperText style={{ color: 'red' }}>
                                    {isFieldFocused ? "" : (errors === "Please enter the email") ? "Enter a Valid Email" : ""}</FormHelperText>
                                <FormHelperText style={{ color: 'red' }}>
                                    {isFieldFocused ? "" : (errors === "Invalid Email") ? "Enter a Valid Email" : ""}</FormHelperText>
                                <FormHelperText style={{ color: 'red' }}>
                                    {isFieldFocused ? "" : (errors === "You have been already Enrolled") ? "Enter a Valid Email" : ""}</FormHelperText>
                                <TextField id="outlined-basic" className='fields mt-3 w-100 ' name='mobile' value={details.mobile}
                                    inputProps={{
                                        maxLength: 10,
                                    }}
                                    onFocus={() => setIsFieldFocused(true)}
                                    onBlur={() => setIsFieldFocused(false)} onChange={onChangeFormData} type='number' label="Moblie" variant="outlined" />
                                <FormHelperText style={{ color: 'red' }}>
                                    {isFieldFocused ? "" : (errors === "Please Enter Phone Number") ? "Enter a Valid Mobile Number" : ""}</FormHelperText>
                                <FormHelperText style={{ color: 'red' }}>
                                    {isFieldFocused ? "" : (errors === "Enter valid phone number") ? "Enter a Valid Mobile Number" : ""}</FormHelperText>
                                <FormControl sx={{ color: 'black' }} className='mt-3 w-100'>

                                    <InputLabel id="demo-simple-select-autowidth-label" className=' w-100'>Course</InputLabel>
                                    <Select
                                        name="course"
                                        labelId="demo-simple-select-autowidth-label"
                                        id="demo-simple-select-autowidth"
                                        value={details.course}
                                        onChange={onChangeFormData}
                                        autoWidth
                                        label="course"
                                        onFocus={() => setIsFieldFocused(true)}
                                        onBlur={() => setIsFieldFocused(false)}
                                    >
                                        {
                                            courselist.map((course) => (
                                                <MenuItem value={course} >{course}</MenuItem>))
                                        }
                                    </Select>
                                </FormControl>
                                <FormHelperText style={{ color: 'red' }}>
                                    {isFieldFocused ? "" : (errors === "Please Select Course") ? "Select a Course" : ""}</FormHelperText>

                                <TextField id="outlined-basic" className='fields mt-3 w-100' multiline minRows={3} name='message' value={details.message} onChange={onChangeFormData} type='text' label="Message" variant="outlined" />

                            </ThemeProvider>
                            <div className='d-flex justify-content-center mt-4 '>
                                <button className='preview-btn px-4 py-1' onClick={onSubmitFormData}>Submit</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
            <div className='certi-main ' id="certificate">
                <div className='certi-container row g-0'>
                    <div className='certi-content col-lg-6'>
                        <span className='certi'>Industry recognized & government approved React certification</span>
                        <p className='certi-text'>Mean Stack was built on the concept of efficiency of performance and fast responses, and it has been very useful in single-page application development, because it is easy to use and completely free, making it accessible to programmers across the world.</p>
                    </div>
                    <div className='certi-certi col-lg-6'>
                        <img className=" " src="../images/cert.svg" width={"100%"} alt='' />
                    </div>
                </div>
            </div>
            <div>
                <Footer/>
            </div>
        </div>
    )
}

export default MeanStack