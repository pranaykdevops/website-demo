
const apiUrl = "http://localhost:8004";


export default apiUrl