import BatchesSchema from "../models/BatchesSchema.js";
export async function addBatch(req, res) {
    try {
        let { title,  slots, trainer, timing, courseduration, internship } = req.body
        if (title === "") {
            return res.status(400).json({ message: "Please Enter The Title " });
        }  else if (trainer === "") {
            return res.status(400).json({ message: "Please Enter The Trainer " });
        } else if (timing === "") {
            return res.status(400).json({ message: "Please Enter The Timing" });
        } else if (courseduration === "") {
            return res.status(400).json({ message: "Please Enter The CourseDuration " });
        } else if (internship === "") {
            return res.status(400).json({ message: "Please Enter The Internship " });
        }else {
            await BatchesSchema.create(req.body);
            return res.status(200).json({ message: "Batch added successfully" });
        }
    }
    catch (err) {
        console.log(err)
    }
}
export async function getallbatches(req, res) {
    try {
        const allBatches = await BatchesSchema.find({});
        return res.status(200).send(allBatches);
    } catch (err) {
        console.log(err)
    }
}
export async function UpdateBatch(req, res) {
    try {
        await BatchesSchema.findByIdAndUpdate(req.params.id, req.body)
        return res.status(200).json({ message: "Batch Updated" })
    }
    catch (err) {
        console.log(err)
    }
}
export async function DeleteBatch(req, res) {
    try {
        await BatchesSchema.findByIdAndDelete(req.params.id)
        return res.status(200).json({ message: "Batch deleted" })
    }
    catch (err) {
        console.log(err)
    }
}