import CourseVideoschema from '../models/BatchVideos.js';
import mongoose from 'mongoose';
import BatchesSchema from '../models/BatchesSchema.js';
export async function AddVideo(req, res) {
    const { filetitle, videostittle, videos, batches } = req.body;
    let existingBatch = await BatchesSchema.findById(batches)
    const video = await CourseVideoschema.create({
        filetitle,
        videostittle,
        videos,
        batches
    });
    try {
        const session = await mongoose.startSession()
        session.startTransaction()
        await video.save({ session })
        existingBatch.videosid.push(video)
        await existingBatch.save({ session })
        await session.commitTransaction()
        return res.status(200).json({ message: "Successful" })
    } catch (err) {
        console.log(err)
        return res.status(500).json({ err })
    }
}
export async function getAllVideos(req, res) {
    try {
        const AllVideos = await CourseVideoschema.find({})
        return res.status(200).send(AllVideos);
    } catch (error) {
        console.log(error)
    }
}
export async function DeleteVideo(req, res) {
    try {
        const videoId = req.params.id;
        if (!videoId) {
            return res.status(400).json({ message: "Invalid video ID" });
        }
        const video = await CourseVideoschema.findByIdAndDelete(videoId).populate("batches");
        if (!video) {
            return res.status(404).json({ message: "No video found to delete" });
        }
        for (const batch of video.batches) {
            const videoIndex = batch.videosid.indexOf(video._id);
            if (videoIndex !== -1) {
                batch.videosid.splice(videoIndex, 1);
                await batch.save();
            }
        }
        return res.status(200).json({ message: "Video deleted" });
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: "Internal server error" });
    }
}
export async function UpdateVideo(req, res) {
    try {
        const { filetitle, videostittle, videos, } = req.body
        await CourseVideoschema.findByIdAndUpdate(req.params.id, req.body)
        return res.status(200).json({ message: "Video Updated" });
    } catch (error) {
        console.log(error)
    }
}
export async function BatchVideo(req, res) {
    try {
        const existingVideo = await BatchesSchema.findById(req.params.id).populate("videosid");
        return res.status(200).json({ existingVideo });
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: 'Internal Server Error' });
    }
}

