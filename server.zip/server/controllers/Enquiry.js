import EnquirySchema from '../models/EnquirySchema.js'
import RegisterModel from '../models/RegisterSchema.js';


export async function Enquiry(req, res) {
    let regex =
        /^[a-zA-Z0-9._%+-]+@gmail.com$/;
    try {
        const { name, email, mobile, course, message } = req.body

        let emailValid = regex.test(email);
        let exist = await EnquirySchema.findOne({ email })
      
        let registered = await RegisterModel.findOne({ email })
        if  (exist) {
            return res.status(400).json({ message: "You have already been Enrolled" })
        } else if(name === "") {
            return res.status(400).json({ message: "please enter the name" })
        } else if (email === "") {
            return res.status(400).json({ message: "Please enter the email" })
        } else if (email !== null) {
            return res.status(400).json({ message: "You are not a registered user" });
        } else if (email !== registered.email) {
            return res.status(400).json({ message: "You are not a registered user" });
        }  else if (!emailValid) {
            return res.status(400).send({ message: "Invalid Email" })
        } else if (mobile === "") {
            return res.status(400).json({ message: "Please Enter Phone Number" })
        } else if (mobile.length !== 10) {
            return res.status(400).json({ message: "Enter valid phone number" })
        } else if (course === "") {
            return res.status(400).json({ message: 'Please Select Course' })
        }
        else {
            await EnquirySchema.create(req.body)
            return res.status(200).json({ message: "Successfull" })
        }
    }
    catch (err) {
        console.log(err)
    }
}


export async function DeleteEnquiry(req, res) {
    try {
        await EnquirySchema.findByIdAndDelete(req.params.id)
        return res.status(200).json({ message: "Enquiry deleted" })
    }
    catch (err) {
        console.log(err)
    }
}

export async function AllEnquiries(req, res) {
    try {
        const AllEnquiry = await EnquirySchema.find({})
        return res.status(200).send(AllEnquiry);
    } catch (err) {
        console.log(err)
    }
}