import mongoose from "mongoose";
import EnrollSchema from "../models/EnrollSchema.js";
import RegisterModel from "../models/RegisterSchema.js";
import BatchesSchema from "../models/BatchesSchema.js";

export async function Enroll(req, res) {
    let regex = /^[a-zA-Z0-9._%+-]+@gmail.com$/;
    try {
        const { firstname, lastname, email, phonenumber, course, trainer, timing, mode, startdate, payment, userid, batches } = req.body;
        const existingUser = await RegisterModel.findById(userid);
        let exist = await EnrollSchema.findOne({ email })
        let emailValid = regex.test(email);
        if (!batches) {
            return res.status(400).json({ message: "Batch ID is required" });
        } else if (exist) {
            return res.status(400).json({ message: "You been already Enrolled" })
        } else if (firstname === "") {
            return res.status(400).json({ message: "please enter the name" })
        } else if (lastname === "") {
            return res.status(400).json({ message: "please enter the last name" })
        } else if (email === "") {
            return res.status(400).json({ message: "Please enter the email" })
        } else if (!emailValid) {
            return res.status(400).send({ message: "Invalid Email" })
        } else if (email !== existingUser.email) {
            return res.status(400).json({ message: "Please Enter registered email" })
        }
        else if (phonenumber === "") {
            return res.status(400).json({ message: "Please Enter Phone Number" })
        } else if (phonenumber.length !== 10) {
            return res.status(400).json({ message: "Enter valid phone number" })
        } else if (course === "") {
            return res.status(400).json({ message: 'Please Select Course' })
        } else if (mode === "") {
            return res.status(400).json({ message: "Select Mode" })
        } else {

            const enroll = new EnrollSchema({
                firstname: firstname,
                lastname: lastname,
                email: email,
                phonenumber: phonenumber,
                course: course,
                trainer: trainer,
                timing: timing,
                mode: mode,
                startdate: startdate,
                payment: payment,
                userid,
                batches
            });
            const session = await mongoose.startSession();
            session.startTransaction();
            try {
                await enroll.save({ session });
                if (!existingUser) {
                    await session.abortTransaction();
                    session.endSession();
                    return res.status(402).json({ msg: 'No User Found By This Id' });
                }
                existingUser.enrolls.push(enroll);
                const existingBatch = await BatchesSchema.findById(batches);
                if (!existingBatch) {
                    await session.abortTransaction();
                    session.endSession();
                    return res.status(402).json({ msg: 'No Batch Found By This Id' });
                }
                existingBatch.enrollid.push(enroll);
                await existingUser.save({ session });
                await existingBatch.save({ session });
                await session.commitTransaction();
                session.endSession();
                return res.status(200).json({ message: "Enrolled Successfully" });
            } catch (err) {
                await session.abortTransaction();
                session.endSession();
                console.log(err);
                return res.status(500).json({ err });
            }
        }
    } catch (err) {
        console.log(err);
        return res.status(500).json({ err });
    }
}

export async function UserEnroll(req, res) {
    let ExistUserEnroll
    let ExistUserBatch
    try {
        ExistUserEnroll = await RegisterModel.findById(req.params.id).populate("enrolls");
        ExistUserBatch = await BatchesSchema.findOne(req.body.id).populate('enrollid');
    } catch (err) {
        return console.log(err);
    }
    if (!ExistUserEnroll) {
        return res.status(404).json({ message: "No Enroll Found" });
    }
    return res.status(200).json({ user: ExistUserEnroll, ExistUserBatch });
}

export async function DeleteEnroll(req, res) {
    try {
        const enrollId = req.params.id;
        const batches = await BatchesSchema.find({ enrollid: enrollId });
        for (const batch of batches) {
            batch.enrollid.pull(enrollId);
            await batch.save();
        }
        const registers = await RegisterModel.find({ enrolls: enrollId });
        for (const register of registers) {
            register.enrolls.pull(enrollId);
            await register.save();
        }
        const deletedEnroll = await EnrollSchema.findByIdAndDelete(enrollId);
        if (!deletedEnroll) {
            return res.status(400).json({ message: "No Enroll Found To Delete" });
        }
        return res.status(200).json({ message: "Enroll Deleted Successfully" });
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: "Internal Server Error" });
    }
}

export async function UpdateEnroll(req, res) {
    try {
        const { payment } = req.body;
        await EnrollSchema.findByIdAndUpdate(req.params.id, { payment: payment });
        return res.status(200).json({ message: "Enroll Updated" });
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "Internal Server Error" });
    }

}

export async function AllEnrolls(req, res) {
    try {
        const AllEnroll = await EnrollSchema.find({})
        return res.status(200).send(AllEnroll);
    } catch (err) {
        console.log(err)
    }
}