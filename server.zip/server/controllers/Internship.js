import InternshipSchema from "../models/InternshipSchema.js";
import InternshipBatchSchema from "../models/InternshipBatchSchema.js";
import RegistreModel from "../models/RegisterSchema.js"
import mongoose from "mongoose";

export async function Internship(req, res) {
    try {
        const totalApplications = await InternshipSchema.countDocuments();
        const { name, email, mobile, passOutYear, internshipBatchId } = req.body;
        const existingInternshipBatch = await InternshipBatchSchema.findById(internshipBatchId);
        const ExistingUser = await RegistreModel.findOne({ email })
        if (!existingInternshipBatch) {
            return res.status(400).json({ message: "Invalid Internship Batch ID" });
        }
        let exist = await InternshipSchema.findOne({ email })
        if (totalApplications >= 999) {
            return res.status(400).json({ message: 'No longer accepting applications' });
        } else if (exist) {
            return res.status(400).json({ message: "You have already been Enrolled" })
        } else if (name === "") {
            return res.status(400).json({ message: "please enter the name" })
        } else if (email === "") {
            return res.status(400).json({ message: "Please enter the email" })
        } else if (email !== null) {
            return res.status(400).json({ message: "You are not a registered user" });
        } else if (email !== ExistingUser.email) {
            return res.status(400).json({ message: "You are not a registered user" });
        } else if (mobile === "") {
            return res.status(400).json({ message: "Please Enter Phone Number" })
        } else if (mobile.length !== 10) {
            return res.status(400).json({ message: "Enter valid phone number" })
        } else if (passOutYear === "") {
            return res.status(400).json({ message: 'Please Enter PassOutYear' })
        } else {
            const internship = await InternshipSchema.create({
                name, email, mobile, passOutYear, internshipBatchId
            });

            try {
                const session = await mongoose.startSession();
                session.startTransaction();
                await internship.save();
                existingInternshipBatch.internshipId.push(internship);
                await existingInternshipBatch.save({ session });
                await session.commitTransaction();
                return res.status(200).json({ message: "Successful" });
            } catch (err) {
                console.log(err);
                return res.status(500).json({ err });
            }
        }
    } catch (err) {
        console.log(err)
        return res.status(500).json({ err });
    }
}


export async function DeleteInternshipUser(req, res) {
    try {
        const id = req.params.id;
        const ExsitingInternshipEnroll = await InternshipBatchSchema.find({ internshipId: id });
        for (const Internal of ExsitingInternshipEnroll) {
            Internal.internshipId.pull(id);
            await Internal.save();
        }
        await InternshipSchema.findByIdAndDelete(req.params.id)
        if (!InternshipSchema) {
            return res.status(400).json({ message: "No Enroll Found To Delete" });
        }
        return res.status(200).json({ message: "Enroll Deleted Successfully" });
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: "Internal Server Error" });
    }
}

export async function AllInternship(req, res) {
    try {
        const AllInternship = await InternshipBatchSchema.findById(req.params.id).populate("internshipId")
        return res.status(200).send(AllInternship);
    } catch (err) {
        console.log(err)
    }
}

export async function AllInternshipBatch(req, res) {
    try {
        const AllInternship = await InternshipSchema.find({})
        return res.status(200).send(AllInternship);
    } catch (err) {
        console.log(err)
    }
}
