import InternshipBatchSchema from "../models/InternshipBatchSchema.js";

export async function addinternshipBatch(req, res) {
    try {
        let { courseDuration, batch, fee} = req.body
        if (courseDuration === "") {
            return res.status(400).json({ message: "Please Enter The courseDuration " });
        }  else if (batch === "") {
            return res.status(400).json({ message: "Please Enter The Batch " });
        } else if (fee === "") {
            return res.status(400).json({ message: "Please Enter The fee" });
        }else {
            await InternshipBatchSchema.create(req.body);
            return res.status(200).json({ message: "Internship batch added successfully" });
        }
    }
    catch (err) {
        console.log(err)
    }
}

export async function getInternshipBatch(req, res) {
    try {
        const allInternshipBatches = await InternshipBatchSchema.find({});
        return res.status(200).send(allInternshipBatches);
    } catch (err) {
        console.log(err)
    }
}

export async function deleteInternshipBatch(req, res) {
    try {
        await InternshipBatchSchema.findByIdAndDelete(req.params.id)
        return res.status(200).json({ message: "Internship Batch deleted" })
    }
    catch (err) {
        console.log(err)
    }
}

export async function updateInternshipBatch(req, res) {
    try {
        await InternshipBatchSchema.findByIdAndUpdate(req.params.id, req.body)
        return res.status(200).json({ message: "Internship Batch Updated" })
    }
    catch (err) {
        console.log(err)
    }
}
