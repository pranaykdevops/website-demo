import NotificationSchema from "../models/NotificationSchema.js";
import BatchesSchema from '../models/BatchesSchema.js';
import mongoose from 'mongoose';



export async function sendMessage(req, res) {
    try {
        const { message, batchId } = req.body
        let existingBatch = await BatchesSchema.findById(batchId)
        const Notification = await NotificationSchema.create({
            message,
            batchId
        });
        try {
            const session = await mongoose.startSession()
            session.startTransaction()
            await Notification.save({ session })
            existingBatch.notificationId.push(Notification)
            await existingBatch.save({ session })
            await session.commitTransaction()
            return res.status(200).json({ message: "Successful" })
        } catch (err) {
            console.log(err)
            return res.status(500).json({ err })
        }
    } catch (err) {
        console.log(err);
        return res.status(500).send(err)
    }
}

export async function getMessage(req, res) {
    try {
        let notifications = await NotificationSchema.find()
        return res.status(200).json(notifications)
    } catch (err) {
        console.log(err)
        return res.status(500).send(err)
    }
}

export async function deleteMessage(req, res) {
    try {
        const notificationId = req.params.id;
        if (!notificationId) {
            return res.status(400).json({ message: "Invalid notification ID" });
        }
        const Notification = await NotificationSchema.findByIdAndDelete(notificationId).populate("batchId");
        if (!Notification) {
            return res.status(404).json({ message: "No Notification found to delete" });
        }
        for (const batch of Notification.batchId) {
            const NotificationIndex = batch.notificationId.indexOf(Notification._id);
            if (NotificationIndex !== -1) {
                batch.notificationId.splice(NotificationIndex, 1);
                await batch.save();
            }
        }
        return res.status(200).json({ message: 'Successfully deleted the notification' });
    } catch (err) {
        console.log(err);
        return res.status(500).send(err)
    }
}

export async function getBatchMessage(req, res) {
    try {
        const existingnotification = await BatchesSchema.findById(req.params.id).populate("notificationId");
        return res.status(200).json({ existingnotification });
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: 'Internal Server Error' });
    }
}
