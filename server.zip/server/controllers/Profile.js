import mongoose from "mongoose";
import ProfileSchema from "../models/ProfileSchema.js";
import RegisterModel from '../models/RegisterSchema.js'

export async function addProfile(req, res) {
    try {
        const { firstName, lastName, email, phoneNumber, instituteName, passedOutYear, branch, linkedin, github, registerId } = req.body
        let existingRegister = await RegisterModel.findById(registerId)
        const Profile = await ProfileSchema.create({
            firstName, lastName, email, phoneNumber, instituteName,
            passedOutYear, branch, linkedin, github, registerId
        });
        if(instituteName===""){
            return res.status(400).json({message:"name is empty"})
        }
        try {
            const session = await mongoose.startSession()
            session.startTransaction()
            await Profile.save({ session })
            existingRegister.profileId.push(Profile)
            await existingRegister.save({ session })
            await session.commitTransaction()
            return res.status(200).json({ message: "Successful" })
        } catch (err) {
            console.log(err)
            return res.status(500).json({ err })
        }
    } catch (err) {
        console.log(err);
        res.status(500).send({ err });
    }
}


export async function updateProfile(req, res) {
    try {
        const { firstName, lastName, email, phoneNumber, houseNumber, streetName, locality, district, city, state, pincode, instituteName, passedOutYear, branch, linkedin, github } = req.body
        await ProfileSchema.findByIdAndUpdate(req.params.id, req.body)
        return res.status(200).json({ message: "Profile updated successfull" })
    } catch (err) {
        console.log(err)
        res.status(500).send({ err })
    }
}

export async function deleteProfile(req, res) {
    try {
        const Profile = req.params.id;
        const registers = await RegisterModel.find({ profileId: Profile });
        for (const register of registers) {
            register.profileId.pull(Profile);
            await register.save();
        }
        const deletedProfile = await ProfileSchema.findByIdAndDelete(Profile);
        if (!deletedProfile) {
            return res.status(400).json({ message: "No Enroll Found To Delete" });
        }
        return res.status(200).json({ message: "Enroll Deleted Successfully" });
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: "Internal Server Error" });
    }
}

export async function getAllProfile(req, res) {
    try {
        const AllProfile = await ProfileSchema.find({})
        return res.status(200).send({ AllProfile })
    } catch (err) {
        console.log(err)
        res.status(500).send({ err })
    }
}

export async function myProfile(req, res) {
    try {
        const existingProfile = await RegisterModel.findById(req.params.id).populate("profileId");
        if (!existingProfile) {
            return res.status(404).send("No user found")
        };
        return res.status(200).json({ existingProfile });
    } catch (err) {
        console.log(err)
        res.status(500).send({ err });
    }
}