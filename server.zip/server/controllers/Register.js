import RegisterModel from "../models/RegisterSchema.js";
import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"
import nodemailer from 'nodemailer'

export async function Register(req, res) {

    let regex =
        /^[a-zA-Z0-9._%+-]+@gmail.com$/;
    try {
        const { name, email, phonenumber, password, payment } = req.body
        let exists = await RegisterModel.findOne({ email });
        let emailValid = regex.test(email);
        if (exists) {
            return res.status(400).json({ message: "You have been already registered" });
        } else if (name === "") {
            return res.status(400).json({ message: "Please enter the name" });
        } else if (email === "") {
            return res.status(400).json({ message: "Please enter the email" });
        } else if (!emailValid) {
            return res.status(400).json({ message: "Email is not valid" });
        } else if (phonenumber === "") {
            return res.status(400).json({ message: "Please enter the mobile number" });
        } else if (phonenumber.length !== 10) {
            return res.status(400).json({ message: "Please enter the correct Number " });
        } else if (password === "") {
            return res.status(400).json({ message: 'Please enter the password' })
        } else if (password.length < 8) {
            return res.status(400).json({ message: "Password should be at least of length 8" })
        }
        else {
            const user = new RegisterModel({
                name,
                email,
                phonenumber,
                password: bcrypt.hashSync(password),
            })
            await RegisterModel.create(user);
            return res.status(200).json({ message: "Registered successfully" });
        }
    } catch (err) {
        console.log(err)
    }
}

export async function DeleteUser(req, res) {
    try {
        await RegisterModel.findByIdAndDelete(req.params.id)
        return res.status(200).json({ message: "User deleted" })
    }
    catch (err) {
        console.log(err)
    }
}

export async function getallRegister(req, res) {
    try {
        const allRegisters = await RegisterModel.find({});
        return res.status(200).send(allRegisters);
    } catch (err) {
        console.log(err)
    }
}

export async function login(req, res) {
    try {
        const { email, password } = req.body
        const exist = await RegisterModel.findOne({ email })
        if (email === "") {
            return res.status(400).json({ message: "Please enter your email" })
        } else if (!exist) {
            return res.status(400).json({ message: "You have not registered, please sign up" })
        } else if (password === "") {
            return res.status(400).json({ message: "Please enter your password" })
        } else if (!bcrypt.compareSync(password, exist.password)) {
            return res.status(400).json({ message: 'Incorrect password' })
        } else {
            const payload = {
                user: {
                    id: exist.id,
                },
            };
            jwt.sign(
                payload,
                process.env.JWT_SECRET,
                { expiresIn: 30000 },
                async (err, token) => {
                    try {
                        if (err) throw err;
                        else {
                            await res.status(200).json({ message: "Login successfull", token, exist });
                        }
                    } catch (e) {
                        console.log(e);
                    }
                }
            );
        }
    } catch (err) {
        console.log(err)
    }
}

export async function UpdatePassword(req, res) {
    try {
        const { password, email } = req.body
        const exists = await RegisterModel.findOne({ email });
        const isPasswordCorrect = bcrypt.compareSync(password, exists.password);
        if (password === isPasswordCorrect) {
            return res.status(400).json({ message: "New password couldnot be same as old password" })
        } else {
            const user = await RegisterModel.findByIdAndUpdate(req.params.id, {
                password: bcrypt.hashSync(password)
            });
            await user.save()
            return res.status(200).json({ message: "Password changed successfully" })
        }
    } catch (err) {
        console.log(err)
    }
}

export async function ForgotPassword(req, res) {
    const { email } = req.body;
    RegisterModel.findOne({ email: email })
        .then(user => {
            if (!user) {
                return res.send({ Status: "User not existed" })
            }
            const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: "5m" })
            var transporter = nodemailer.createTransport({
                service: 'gmail',
                auth: {
                    user: "no-reply",
                    pass: 'dfkb ymij mnfm pzem'
                }
            });
            var mailOptions = {
                from: 'no-reply',
                to: user.email,
                subject: 'Reset Password Link',
                text: `https://www.techu.in/resetPassword/${user._id}/${token}`
            };

            transporter.sendMail(mailOptions, function (error, info) {
                if (error) {
                    console.log(error)
                } else {
                    return res.status(200).json({ message: "Link is sent successfully to your Gmail" })
                }
            });
        })
}

export async function ResetPassword(req, res) {
    const { id, token } = req.params
    const { password } = req.body

    jwt.verify(token, JWT_SECRET, (err, decoded) => {
        if (password == "") {
            return res.status(400).json({ message: "Enter your password" })
        }
        else {
            bcrypt.hash(password, 10)
                .then(hash => {
                    RegisterModel.findByIdAndUpdate({ _id: id }, { password: hash })
                        .then(u => res.status(200).json({ message: "Password updated successfully, please login!" }))
                        .catch(err => res.send({ Status: err }))
                })
                .catch(err => res.send({ Status: err }))
        }
    })
}

export async function User(req, res) {
    try {
        const User = await RegisterModel.findById(req.params.id)
        if (!User) {
            return res.status(400).json({ message: "No such user" })
        }
        res.status(200).send(User)
    } catch (err) {
        console.log(err)
    }
}
