import mongoose from "mongoose";

const Schema = mongoose.Schema

const CourseVideoschema = new Schema({
    filetitle: {
        type: String,
        required: true,
    },
    videostittle: {
        type: String,
        required: true,
    },
    videos: {
        type: String,
        required: true,

    }, batches: [{
        type: mongoose.Types.ObjectId,
        ref: "Batch",
        required: true
    }],
})

export default mongoose.model("BatchVideos", CourseVideoschema)