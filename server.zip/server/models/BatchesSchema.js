import mongoose from 'mongoose'


const schema = mongoose.Schema

const BatchSchema = new schema({
    title: {
        type: String,
        required: true,
        trim: true
    },
    batch: {
        type: Number,
        required: true,
        trim: true
    },
    startdate: {
        type: String,
        required: true,
        trim: true
    },
    trainer: {
        type: String,
        required: true,
        trim: true
    },
    timing: {
        type: String,
        required: true,
        trim: true
    },
    courseduration: {
        type: Number,
        required: true,
        trim: true
    },
    internship: {
        type: Number,
        required: true,
        trim: true
    },
    slots: {
        type: Number,
        default: 25
    },
    videosid: [{
        type: mongoose.Types.ObjectId,
        ref: "BatchVideos",
        required: true
    }],
    enrollid: [{
        type: mongoose.Types.ObjectId,
        ref: "Enroll",
        require: true
    }], notificationId: [{
        type: mongoose.Types.ObjectId,
        ref: "Notification",
        required: true
    }]


})

export default mongoose.model('Batch', BatchSchema)