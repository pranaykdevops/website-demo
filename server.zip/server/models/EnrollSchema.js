import mongoose from "mongoose";

const schema = mongoose.Schema

const EnrollSchema = new schema({
    firstname: {
        type: String,
        trim: true,
        required: true
    },
    lastname: {
        type: String,
        trim: true,
        required: true
    }
    ,
    email: {
        type: String,
        trim: true,
        unique: true,
        required: true
    },
    phonenumber: {
        type: Number,
        trim: true,
        required: true
    }, trainer: {
        type: String,
        trim: true,
        required: true
    },
    timing: {
        type: String,
        trim: true,
        required: true
    },
    course: {
        type: String,
        trim: true,
        required: true
    },
    startdate: {
        type: String,
        trim: true,
        required: true
    },
    mode: {
        type: String,
        required: true,
        enum: ['online', 'offline']
    },
    payment: {
        type: Boolean,
        default: false
    },
    userid: [{
        type: mongoose.Types.ObjectId,
        ref: "Register",
        required: true,
    }],
    batches: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "Batch",
        required: true
    }]
})

export default mongoose.model("Enroll", EnrollSchema)