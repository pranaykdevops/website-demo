import mongoose from 'mongoose'


const Schema = mongoose.Schema

const InternshipBatchSchema = new Schema({
    courseDuration: {
        type: String,
        required: true
    },
    batch: {
        type: String,
        required: true,

    },
    fee: {
        type: String,
        required: true
    },
     internshipId: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "Intership",
        required: true
    }]
})

export default mongoose.model("intershipBatch", InternshipBatchSchema);