import mongoose from 'mongoose'


const Schema = mongoose.Schema

const InternshipSchema = new Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    mobile: {
        type: Number,
        required: true
    },
    passOutYear: {
        type: Number,
        required: true,
    },
    internshipBatchId: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "intershipBatch",
        required: true
    }]
})

export default mongoose.model("Intership", InternshipSchema);