import mongoose from 'mongoose'

const Schema = mongoose.Schema

const NotificationSchema = new Schema({
    message: {
        type: String,
        required: true
    },
    batchId: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "Batch",
        required: true
    }]
}, { timestamps: true });


export default mongoose.model('Notification', NotificationSchema);

