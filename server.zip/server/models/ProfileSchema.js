import mongoose from "mongoose"

const Schmea = mongoose.Schema


const ProfileSchema = new Schmea({
    firstName: {
        type: String,
        required: [true, "Please provide your First Name"]
    }, lastName: {
        type: String,
        required: [true, "Please provide your Last Name"]
    }, email: {
        type: String,
        required: [true],
        unique: true,
    }, phoneNumber: {
        type: String,
        required: [true, "Provide your PhoneNumber"]
    }, houseNumber: {
        type: String,
    }, streetName: {
        type: String
    }, locality: {
        type: String
    }, district: {
        type: String
    }, city: {
        type: String
    }, state: {
        type: String
    }, Pincode: {
        type: Number
    }, instituteName: {
        type: String,
        required: [true, "Institute name is Required"],
    }, passedOutYear: {
        type: Date,
        required: [true, "Passout year is Required"],
    }, branch: {
        type: String,
        required: [true, "Branch is Required"],
    }, linkedin: {
        type: String,
        required: true
    }, github: {
        type: String,
        required: true
    },registerId:[{
        type: mongoose.Types.ObjectId,
        ref: "Register",
        required: true
    }],

})

export default mongoose.model("Profile", ProfileSchema);