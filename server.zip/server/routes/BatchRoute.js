import { Router } from "express";
import { UpdateBatch, addBatch, DeleteBatch, getallbatches } from "../controllers/Batch.js";

const batchRoute = Router()

batchRoute.post('/upcoming', addBatch)
batchRoute.get('/all', getallbatches)
batchRoute.patch('/update/:id', UpdateBatch)
batchRoute.delete('/delete/:id', DeleteBatch)
export default batchRoute