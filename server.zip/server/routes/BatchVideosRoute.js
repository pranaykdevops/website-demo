import express from 'express'
import { AddVideo, BatchVideo, DeleteVideo, UpdateVideo, getAllVideos } from '../controllers/BatchVideos.js'


const videoRoute = express.Router()

videoRoute.post('/addvideo', AddVideo)
videoRoute.get('/allvideos', getAllVideos)
videoRoute.get('/batchvideo/:id', BatchVideo)
videoRoute.delete('/deletevideo/:id', DeleteVideo)
videoRoute.patch('/updatevideo/:id', UpdateVideo)


export default videoRoute