import { Router } from "express";
import { AllEnquiries, DeleteEnquiry, Enquiry } from "../controllers/Enquiry.js";

const enquiryRoute = Router()

enquiryRoute.post('/enquiry', Enquiry)
enquiryRoute.get('/allEnquiry', AllEnquiries)
enquiryRoute.delete('/deleteEnquiry/:id', DeleteEnquiry)

export default enquiryRoute