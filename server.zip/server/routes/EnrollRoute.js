import { Enroll, AllEnrolls, DeleteEnroll, UpdateEnroll, UserEnroll } from "../controllers/Enroll.js";
import { Router } from "express";

const enrollRoute = Router()

enrollRoute.post('/Enroll', Enroll)
enrollRoute.get('/allEnrolls', AllEnrolls)
enrollRoute.patch('/updateEnrolls/:id', UpdateEnroll)
enrollRoute.delete('/deleteEnroll/:id', DeleteEnroll)
enrollRoute.get("/myEnroll/:id", UserEnroll)



export default enrollRoute