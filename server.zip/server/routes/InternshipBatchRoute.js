import { Router } from "express";
import { addinternshipBatch, deleteInternshipBatch, getInternshipBatch, updateInternshipBatch } from "../controllers/InternshipBatch.js";



const InternshipBatchRoute = Router()

InternshipBatchRoute.post('/addinternship', addinternshipBatch)
InternshipBatchRoute.get('/allinternship', getInternshipBatch)
InternshipBatchRoute.delete('/deleteinternship/:id', deleteInternshipBatch)
InternshipBatchRoute.patch('/updateinternship/:id', updateInternshipBatch)

export default InternshipBatchRoute


  