import { Router } from "express";
import { AllInternship, AllInternshipBatch, DeleteInternshipUser, Internship } from "../controllers/Internship.js";

const internshipRoute=Router()

internshipRoute.post('/addinternship',Internship)
internshipRoute.get('/allinternship/:id',AllInternship)
internshipRoute.get('/allinternshipbatch',AllInternshipBatch)
internshipRoute.delete('/deleteuser/:id',DeleteInternshipUser)

export default internshipRoute