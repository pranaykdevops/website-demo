import { Router } from "express"
import { deleteMessage, getBatchMessage, getMessage, sendMessage } from "../controllers/Notifications.js"

const NotificationRoute = Router()

NotificationRoute.post('/sendMessage', sendMessage)
NotificationRoute.get('/getMessage', getMessage)
NotificationRoute.get('/getMessage/:id', getBatchMessage)
NotificationRoute.delete('/deleteMessage/:id', deleteMessage)

export default NotificationRoute