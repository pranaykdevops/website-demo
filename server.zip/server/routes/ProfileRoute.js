import { Router } from "express";
import { addProfile, deleteProfile, getAllProfile, myProfile, updateProfile } from "../controllers/Profile.js";

const profileRoute=Router()

profileRoute.get('/allProfiles',getAllProfile)
profileRoute.post('/addProfile',addProfile)
profileRoute.patch('/updateProfile/:id',updateProfile)
profileRoute.delete('/deleteProfile/:id',deleteProfile)
profileRoute.get('/myProfile/:id',myProfile)

export default profileRoute