
import { Router } from "express";
import { DeleteUser, Register, getallRegister, login, ForgotPassword, ResetPassword, UpdatePassword, User } from "../controllers/Register.js";
import { AdminLogin, AdminRegister } from "../controllers/Admin.js";

const registerRoute = Router()

registerRoute.post('/Register', Register)
registerRoute.get('/allRegister', getallRegister)
registerRoute.post('/Login', login)
registerRoute.post('/adminLogin', AdminLogin)
registerRoute.post('/adminRegister', AdminRegister)
registerRoute.delete('/deleteUser/:id', DeleteUser)
registerRoute.patch("/ChangePassword/:id", UpdatePassword)
registerRoute.post('/forgot-password', ForgotPassword)
registerRoute.post('/reset-password/:id/:token', ResetPassword)
registerRoute.get('/UserDetails/:id', User)

export default registerRoute