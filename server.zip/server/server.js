import express from 'express'
import dotenv from 'dotenv'
import cors from 'cors'
import connect from './database/connect.js'
import registerRoute from './routes/RegisterRoute.js'
import batchRoute from './routes/BatchRoute.js'
import enrollRoute from './routes/EnrollRoute.js'
import enquiryRoute from './routes/EnquiryRoute.js'
import internshipRoute from './routes/InternshipRoute.js'
import videoRoute from './routes/BatchVideosRoute.js'
import bodyParser from 'body-parser'
import profileRoute from './routes/ProfileRoute.js'
import NotificationRoute from './routes/NotificationRoute.js'
import InternshipBatchRoute from './routes/InternshipBatchRoute.js'

const app = express()
app.use(express.json());
dotenv.config();
app.use(cors())
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  next();
});
app.use(bodyParser.json({ limit: '100mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '100mb' }));
app.use('/user', registerRoute)
app.use('/batches', batchRoute)
app.use('/', enrollRoute)
app.use('/', enquiryRoute)
app.use('/Internship', internshipRoute)
app.use('/', videoRoute)
app.use('/', profileRoute)
app.use('/', NotificationRoute)
app.use('/', InternshipBatchRoute)

const port = process.env.PORT || 8004
// app.get('*', (req, res) => {
//   res.sendFile(path.join(__dirname, 'client', 'build', 'index.html'));
// });
// const server = import('C:\\Inetpub\\vhosts\\techu.in\\server.techu.in\\server.js');


connect().then(() => {
  try {
    app.listen(port, () => {
      console.log(`listening to  ${port}`)
    })
  } catch (err) {
    console.log('cannot connect with the server')
  }
}).catch((err) => {
  console.log('failed to connect with the database', err)
})
